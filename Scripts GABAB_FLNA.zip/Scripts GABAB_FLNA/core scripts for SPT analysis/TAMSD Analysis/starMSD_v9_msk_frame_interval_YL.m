% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [MSD,D_list,D_mean]=starMSD_v9_msk_frame_interval_YL(movie_name, channel_number, Frames,timeWindowPlot,max_window, parameter, global_folders)
% global MSDfolder
% function starMSD_3v4(filename, D_min)

% a routine to calulate diffusion coefficient and generate MSD plot
% clusify and cluster particles according to a diffusion model 'a*t^b';
% when a is diffusion coefficient, b is anomolous factor

% clustering is difined by 'a' and 'b' from the fitting
% Confined          when a < D_min, default D_min = 0.01
% Sub-diffusion     when a > D_min and b < alpha_min, default alpha_min = 0.8
% Super-diffusion   when a > D_min and b > alpha_max, default alpha_min = 1.2
% normal diffusion  is all the rest, i.e., a > D_min and alpha_min =< b =< alpha_max

% results are kept in
% 'MSDfit_coeff' (1st column=a, 2nd column=b),
% 'c' (class after clustering, 1=confined, 2=sub-diffusion, 3=normal diffusion, 4=super-diffusion)
% 'MSDfit_coeff_cl' stores class, trajectory no., a and b.

% All parameters are kept in 'All_model_results'
% column1 = number of particle
% column2 = fraction
% column3 = mean of diffusion coefficient
% column4 = SEM
% column5 = mode of diffusion

% example command
% % starMSD_4v1('a2A-Basal');
% % starMSD_4v1('a2A-UK');
% % starMSD_4v1('Gi-Basal');
% % starMSD_4v1('Gi-UK');

% for testing:
% % starMSD_4v1('001-a2A-Basal');

%%% simulation movie
% % starMSD_4v1('sim833sim840C2');

% 4v1. Version created for Nature revision based on 3v4. It takes into account
% localization error!!!!!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% load combined _gui2_steps file
%load([filename '-OBJ2.mat']);
filename=[movie_name, '-C', num2str(channel_number)];
load([global_folders.rawfolder, filesep,filename '_gui2_steps.mat']);

[Ch] = load_data_XY_v1(movie_name,channel_number,parameter,global_folders);
Ch(channel_number).OBJ.class=OBJ2.class;
Ch(channel_number).OBJ.xR=OBJ2.xR(Ch(channel_number).OBJ.class>0,Frames(1):Frames(2));
Ch(channel_number).OBJ.yR=OBJ2.yR(Ch(channel_number).OBJ.class>0,Frames(1):Frames(2));
Ch(channel_number).OBJ.trjRB=Ch(channel_number).OBJ.trjRB(Ch(channel_number).OBJ.class>0,Frames(1):Frames(2));

Frames=min(Frames,numel(TME));

%load(filename);

%%% options for ploting and saving
save_workspace=1;   % 1=save workspace
selected_plot=0;    % 1= plot selected MSD and trajectory from each class as a subplot
ind_plot=0;         % 1= plot selected MSD and trajectory as individual figure
save_ind_plot=0;    % 1= save individual plot
sub_plot=0;         % 1= plot selected MSD and trajectory from each class as a subplot
save_subplot=0;     % 1= save selected MSD and trajectory subplot as .fig and .eps // valid with selected_plot=1
plot_hist=0;        % 1= plot histogram of D as a subplot
save_histplot=0;    % 1= save histogram plot as .fig and .eps // valid with plot_hist=1

%% parameters
numFrames=Frames(2)-Frames(1)+1; %default=100; %number of frames to be analysed
%timeWindowPlot=100; %default=120; %used to analyze and plot only objects that last >=timeWindow

%for real data
%fram_num=10;
timeWindowFraction=max_window/timeWindowPlot;%0.35;%fram_num/numFrames;%0.35; %default=0.35; fraction of timeWIndowPlot used in the analysis

%for simulations
%timeWindowFraction=0.2; %default=0.8; fraction of timeWIndowPlot used in the analysis


pixelSize=parameter.pixel_size_um;  %pixle size in um 0.1067

step_size_fraction=0.2; %obsolete!!! default=0.2 fraction of object lifetime used for MSD slope calculation
usealldata=1; %default=1!!!! if=1, uses all data points available! 0 is obsolete!

% TME contains time information in milliseconds. Here we convert it into seconds
TMEsec=TME/1000;

% parameter for clustering !!!!!!!!!!
D_min=0.01; %[0.01, 0.05, 0.1, 0.2, 0.5];       %% minimum D to define confined movement
alpha_subD=0.75; %[0.5, 0.6, 0.75, 0.8, 0.9];    %% maximum alpha for sub-diffusion
alpha_supD=1.25; %[1.5, 1.4, 1.25, 1.2, 1.1];    %% minimum alpha for super-diffusion
D_name=D_min*100;

%computing square displacements for each object

exclude_outside_mask=1; %1 to exclude OBJs outside mask

% localization error!!!! added in Nature revision!
% For correction use the following equations:
% MSD=4*D*delta_t + 4*sigma^2; where sigma is the localization error (standard deviation) calculated with sigma_calculator
% Dapparent = Dreal + sigma/delta_t
% loc_err_sigma=0.023; - the value used in Germany with 95nm pixel size
loc_err_sigma=0.020;

% remember that sigma(standard deviation) is sqrt(variance)
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ObjNum=size(Ch(channel_number).OBJ.xR,1);
%for testing:
%ObjNum=1000;
%adding NaNs
xnan=find(isnan(Ch(channel_number).OBJ.trjRB));
Ch(channel_number).OBJ.xR(xnan)=NaN;
Ch(channel_number).OBJ.yR(xnan)=NaN;

%selecting only objects in specified class
if exclude_outside_mask==1
  image_msk= imread([global_folders.rawfolder, filesep,filename,'_msk.tif']);  
   image_msk(image_msk>0)=1;
  %% find those inside msk
  int_x=floor(Ch(channel_number).OBJ.xR);
int_y=floor(Ch(channel_number).OBJ.yR);

 list_in_msk=zeros(size(Ch(channel_number).OBJ.xR));
 list_exist=~isnan(Ch(channel_number).OBJ.xR) & ~isnan(Ch(channel_number).OBJ.yR);
 list_in_msk(list_exist)=double(image_msk(sub2ind(size(image_msk),int_y(list_exist),int_x(list_exist))))==1;
list_exist(list_in_msk==0)=0;

Ch(channel_number).OBJ.xR(list_exist==0)=nan;
    Ch(channel_number).OBJ.yR(list_exist==0)=nan;

%   classf=find( Ch(channel_number).OBJ.class==0);
%     Ch(channel_number).OBJ.xR(classf,:)=NaN;
%     Ch(channel_number).OBJ.yR(classf,:)=NaN;
end

for objr=1:ObjNum
    existX=find(isnan(Ch(channel_number).OBJ.xR(objr,1:numFrames))==0);
    
    existFrames(objr)=numel(existX);
    
    OBJsync(objr).x(1:numel(existX))=Ch(channel_number).OBJ.xR(objr,existX)*pixelSize;
    OBJsync(objr).y(1:numel(existX))=Ch(channel_number).OBJ.yR(objr,existX)*pixelSize;
    SD(objr).step(1:numel(existX))=0;
end




MSD(1:ObjNum,2:numFrames)=NaN;



%SD(1:ObjNum,1:numFrames)=0;


ddd=0;

%% calculate mean lifetime of objects
meanlife=mean(existFrames(existFrames>0));


for objj =1:ObjNum
    
    
    
    
    if usealldata==1
        maxStepSize=existFrames(objj)-1;
        
    else
        
        maxStepSize=min([meanlife*0.5 existFrames(objj)*step_size_fraction]);
        
    end
    
    
    %for stepSize=1:round((existFrames(objj)-1)*step_size_fraction);
    
    for stepSize=1:round(maxStepSize);
        
        currentFrame=1;
        stepNumber=0;
        
        ddd=ddd+1;
        
        %stepSize=3;
        
        while currentFrame <= existFrames(objj)-stepSize
            
            stepNumber=stepNumber+1;
            
            SD(objj).step(stepSize+1) = SD(objj).step(stepSize+1) + ((OBJsync(objj).x(currentFrame+stepSize)-OBJsync(objj).x(currentFrame))^2 + (OBJsync(objj).y(currentFrame+stepSize)-OBJsync(objj).y(currentFrame))^2);
            
            currentFrame=currentFrame+1;
        end
        
        
        MSD(objj,stepSize+1)=SD(objj).step(stepSize+1)/stepNumber;
        
    end
end


%computing MSDs for every object

%MSD(1:ObjNum,1:numFrames-1)=NaN;


%% correcting for the localization error


MSD=MSD - 4*loc_err_sigma^2;
MSD(:,1)=0;


%% calculating the average MSD
% figure (1);
% hold on;
% for q=1:ObjNum
%     plot (TMEsec(1:numFrames)',MSD(q,1:numFrames), 'b');
%     
% end
% hold off;
% 
% figure (2);
% aMSD=nanmean(MSD,1);

% hold on
% plot (TMEsec(1:numFrames)',aMSD, 'r');

%% calculate 25%-75% confidenceinterval

error=iqr(MSD,1);

% plot(TMEsec(1:numFrames)',aMSD+error, 'g');
% plot(TMEsec(1:numFrames)',aMSD-error, 'g');
% 
% hold off

%% plotting only data that exist at time_window=9.6s
%figure ('name','aMSD only of objects existing for entire time window');

MSD2=MSD(existFrames>=timeWindowPlot,1:timeWindowPlot*timeWindowFraction);

xR_selected=Ch(channel_number).OBJ.xR(existFrames>=timeWindowPlot,:); %$contains coordinates of all objects used for MSD calculation and clustering
yR_selected=Ch(channel_number).OBJ.yR(existFrames>=timeWindowPlot,:);

aMSD2=nanmean(MSD2,1); %old (rev1)

aMSD3=median(MSD2,1); %new (rev2)!!!!!!!!!!

% 
% hold on
% 
% plot (TMEsec(1:timeWindowPlot*timeWindowFraction)',aMSD2, 'r');
% 
% plot (TMEsec(1:timeWindowPlot*timeWindowFraction)',aMSD3, 'b');

%calculate 25%-75% confidenceinterval

q75=quantile(MSD2,.75,1);
q25=quantile(MSD2,.25,1);
%error2=range(MSD2,1);


%plot(TMEsec(1:timeWindowPlot)',MSD2(slowest_i,:), 'g');
%plot(TMEsec(1:timeWindowPlot)',MSD2(fastest_i,:), 'g');
% 
% plot(TMEsec(1:timeWindowPlot*timeWindowFraction)',q75, 'g');
% plot(TMEsec(1:timeWindowPlot*timeWindowFraction)',q25, 'g');
% 
% hold off


%new plot

%figure

% h=area(TMEsec(1:timeWindowPlot*timeWindowFraction)',[q25; q75-q25]');
% 
% set(h(1),'FaceColor',[1 1 1]);
% set(h(2),'FaceColor',[.5 .5 .5]);
% set(h,'LineStyle','none');

% 
% hold on
% plot (TMEsec(1:timeWindowPlot*timeWindowFraction)',aMSD2, 'r');
% plot (TMEsec(1:timeWindowPlot*timeWindowFraction)',aMSD3, 'b');

% selected=[];
% 
% for s=selected
%     
%     plot(TMEsec(1:timeWindowPlot*timeWindowFraction)',MSD(s,1:timeWindowPlot*timeWindowFraction), 'k');
%     
%     
% end
% 
% hold off
% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% clustering

%converting data to logarithm - clustering seem to work better, expecially
%to distinguish immobile fraction!!!!!!

stdMSD2=std(MSD2,0,2);
stdMSD2=repmat(stdMSD2,1,size(MSD2,2));
MSD2clust=MSD2 ./stdMSD2;


%%%%%clustering based on individual fitting
for n=1:size(MSD2,1)
    
    model = fittype('a*t^b','independent','t');
    
    options=fitoptions(model);
    
    options.Lower = [0 0.001];
    
    options.Start = [0.2 1];
    
    options.Upper = [3 3];
    
    
    MSDfit=fit(TMEsec(1:timeWindowPlot*timeWindowFraction),MSD2(n,:)',model,options);
    
    
    % %temporary for checking fitting
    % z=figure;
    % plot (TMEsec(1:timeWindowPlot*timeWindowFraction),MSD2(n,:)')
    % hold on
    % plot(MSDfit)
    % waitfor(z)
    % %
    
    if ~isempty(coeffvalues(MSDfit))
    MSDfit_coeff(n,:)=coeffvalues(MSDfit);
    else
        MSDfit_coeff(n,:)=nan(1,size(MSDfit_coeff,2));
    end
    
end


stdMSDfit_coeff=repmat(std(MSDfit_coeff),size(MSD2,1),1);

%close all

MSDfit_coeff_ori=MSDfit_coeff;          %% keep result from fitiitng
MSDfit_coeff(:,1)=MSDfit_coeff(:,1)./4; %% a/4 to get D !!!!!!!!!!!!!!!!!!!!!!!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Define 'c' class according to individual fit
% clustering is difined by 'a' and 'b' from the fitting
% class 1 Confined          when a < D_min, default D_min = 0.01
% class 2 Sub-diffusion     when a > D_min and b < alpha_min, default alpha_min = 0.8
% class 4 Super-diffusion   when a > D_min and b > alpha_max, default alpha_min = 1.2
% class 3 normal diffusion  is all the rest, i.e., a > D_min and alpha_min =< b =< alpha_max

for jj=1:size(MSDfit_coeff, 1)
    
    
    if MSDfit_coeff(jj, 1)<D_min; %%0.01 %% 0.005  %% Define immobile particle
        c(jj) = 1;
    elseif MSDfit_coeff(jj, 2)<alpha_subD; %%0.8  %% 0.75 %% Define sub-diffusion
        c(jj) = 2;
    elseif MSDfit_coeff(jj, 2)>alpha_supD; %%1.2  %% 1.25 %% Define super-diffusion
        c(jj) = 4;
    else
        c(jj) = 3;  %% Define normal-diffusion
    end
    
end

%%% MSD-clustering plot

% figure ('name',[filename '-MSD-Clustering'])
% hold on
% 
% if any(c==4)
%     plot(1:timeWindowPlot*timeWindowFraction, MSD2(c==4,:),'r')
% end
% 
% if any(c==3)
%     plot(1:timeWindowPlot*timeWindowFraction, MSD2(c==3,:),'g')
% end
% 
% if any(c==2)
%     plot(1:timeWindowPlot*timeWindowFraction, MSD2(c==2,:),'b')
% end
% 
% if any(c==1)
  %  plot(1:timeWindowPlot*timeWindowFraction, MSD2(c==1,:),'k')
%end

%hold off


timelags=TMEsec;

models = {'Confined','Sub-diff.','Normal diff.','Super-diff.'};

%% Ploting all MSD and trajectory from each class
%fr_num=max(c);
exist_c=unique(c);
axs=timeWindowPlot*timeWindowFraction*0.0284;
% for f=exist_c
%     
%     figure ('name',['fraction ' num2str(f)])
%     
%     %plot(TMEsec(1:timeWindowPlot), MSD2(c==f,:))
%     plot(TMEsec(1:timeWindowPlot*timeWindowFraction), MSD2(c==f,:))
%     axis([0 axs 0 4]);
% 
%     figure ('name',['fraction ' num2str(f)])
%     plot (xR_selected(c==f,1:numFrames)',yR_selected(c==f,1:numFrames)')
%     axis([0 250 0 250]);
%     
%     All_model_dist(f, f)=1; % matrix to show a model for each fraction
%     
%     All_model_dist(f,numel(models)+1)=numel(find(c==f)); % column 5 shows number of paticles belonged to that model
%     All_model_dist(f,numel(models)+2)=numel(find(c==f))/numel(c); % column 6 shows fraction of paticles belonged to that model
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% selected plot, subplot

if selected_plot==1
    m=size(MSD2, 1); %% total particles used in the MSD calculation
    %fr_num=max(c);
    exist_c=unique(c);
    
    c2=c';
    axs=1; %timeWindowPlot*timeWindowFraction*0.0284;
    
    
    %%%%% individual plot
    
    if ind_plot==1
        
        for f=exist_c
            
            n=round(All_model_dist(f,numel(models)+1)*100/m);  %% define step size for particle selection
            
            %%% define selected particles for ploting '_pl'
            MSD2_pl=MSD2(1:n:m,:);
            xR_selected_pl=xR_selected(1:n:m,:);
            yR_selected_pl=yR_selected(1:n:m,:);
            c_gr_pl=c2(1:n:m,:);
            
            if sum(c_gr_pl==f)~=0
                %subplot(2,2,f)
                
                %%% ploting
                figure ('name',['Selected-MSD-' num2str(f) '-' char(models(find(All_model_dist(f, 1:4)==1)))])
                plot(TMEsec(1:timeWindowPlot*timeWindowFraction), MSD2_pl(c_gr_pl==f,:))
                %plot(TMEsec(1:size(MSD2_pl(c_gr_pl==f,:),2)), MSD2_pl(c_gr_pl==f,:))
                axis([0 axs 0 2]);
                %title(['Selected-Group-' num2str(f) '-' char(models(find(All_model_dist(f, :)==1)))]);
                
                if save_ind_plot==1
                    
                    saveas(gcf,[global_folders.MSDfolder, filesep, filename '-Selected-MSD-Cl-' num2str(f)],'fig')
                    % print([filename '-Selected-MSD-Cl-' num2str(f)],'-depsc','-r300')
                    % print([filename '-Selected-MSD-Cl-' num2str(f)],'-dsvg')
                end
                
                figure ('name',['Selected-Trajectory-' num2str(f) '-' char(models(find(All_model_dist(f, 1:4)==1)))])
                plot (xR_selected_pl(c_gr_pl==f,1:numFrames)',yR_selected_pl(c_gr_pl==f, 1:numFrames)')
                %title(['Selected-Group-' num2str(f) '-' char(models(find(All_model_dist(f, :)==1)))]);
                axis([0 250 0 250], 'square');
                
                if save_ind_plot==1
                    
                    saveas(gcf,[global_folders.MSDfolder, filesep, filename '-Selected-Trj-Cl-' num2str(f)],'fig')
                    % print([filename '-Selected-Trj-Cl-' num2str(f)],'-depsc','-r300')
                    % print([filename '-Selected-Trj-Cl-' num2str(f)],'-dsvg')
                end
            end
        end
        
    end
    if sub_plot==1
        
        %%%%% subplot
        figure ('name',['Selected-Regroup-MSD-fraction'])
        
        for f=exist_c
            subplot(2,2,f)
            %%% define selected particles for ploting '_pl'
            MSD2_pl=MSD2(1:n:m,:);
            xR_selected_pl=xR_selected(1:n:m,:);
            yR_selected_pl=yR_selected(1:n:m,:);
            c_gr_pl=c2(1:n:m,:);
            
%             if numel(MSD2_pl(c_gr_pl==f,:))>0
%                 n=round(All_model_dist(f,numel(models)+1)*150/m);  %% define step size for particle selection
%                 
%                 %%% plotting
%                 %figure ('name',['Selected-Regroup-MSD-fraction ' num2str(f)])
%                 plot(TMEsec(1:timeWindowPlot*timeWindowFraction), MSD2_pl(c_gr_pl==f,:))
%                 axis([0 axs 0 2], 'square');
%                 title(['Selected-Group-' num2str(f) '-' char(models(find(All_model_dist(f, 1:4)==1)))]);
%             end
        end
%         axes;
%         %h = title([filename]);
%         h = title([filename]);
%         set(gca,'Visible','off');
%         set(h,'Visible','on');
%         
        if save_subplot==1
            
            saveas(gcf,[global_folders.MSDfolder, filesep, filename '-Selected-MSD2'],'fig')
            % print([filename '-Selected-MSD2'],'-depsc','-r300')
            % print([filename '-Selected-MSD2'],'-dsvg')
        end
        
    %    figure ('name',['Selected-Regroup-Trajectory-fraction'])
        
        for f=exist_c
            if sum(c_gr_pl==f)~=0
                n=round(All_model_dist(f,numel(models)+1)*150/m);  %% define step size for particle selection
                
                %%% define selected particles for ploting '_pl'
                MSD2_pl=MSD2(1:n:m,:);
                xR_selected_pl=xR_selected(1:n:m,:);
                yR_selected_pl=yR_selected(1:n:m,:);
                c_gr_pl=c2(1:n:m,:);
                
%                 subplot(2,2,f)
%                 
%                 %%% ploting
%                 
%                 %figure ('name',['Selected-Regroup-Trajectory-fraction ' num2str(f)])
%                 plot (xR_selected_pl(c_gr_pl==f,1:numFrames)',yR_selected_pl(c_gr_pl==f, 1:numFrames)')
%                 title(['Selected-Group-' num2str(f) '-' char(models(find(All_model_dist(f, 1:4)==1)))]);
%                 axis([0 250 0 250],'square');
            end
        end
%         axes;
%         h = title([filename]);
%         set(gca,'Visible','off');
%         set(h,'Visible','on');
%         
%         if save_subplot==1
%             saveas(gcf,[global_folders.MSDfolder, filesep, filename '-Selected-trajectory2'],'fig')
%             % print([filename '-Selected-trajectory2'],'-depsc','-r300')
%             % print([filename '-Selected-trajectory2'],'-dsvg') %to save as
%             % svg as well
%         end
    end
end


%% generate result matrix
for f=exist_c
    MSDfit_coeff_cl{f}=find(c==f)';
    for i=1:numel(MSDfit_coeff_cl{f})
        MSDfit_coeff_cl{f}(i, 1:4)=[c((MSDfit_coeff_cl{f}(i))) (MSDfit_coeff_cl{f}(i)) MSDfit_coeff((MSDfit_coeff_cl{f}(i)), :)];
    end
    
    All_model_dist(f, numel(models)+3)=mean(MSDfit_coeff_cl{f}(:,3));
    All_model_dist(f, numel(models)+4)=std(MSDfit_coeff_cl{f}(:,3))/sqrt(size(MSDfit_coeff_cl{f},1));
    All_model_dist(f, numel(models)+5)=mean(MSDfit_coeff_cl{f}(:,4));
    All_model_dist(f, numel(models)+6)=std(MSDfit_coeff_cl{f}(:,4))/sqrt(size(MSDfit_coeff_cl{f},1));
    
end

%% generate result matrix
% column1 = number of particle
% column2 = fraction
% column3 = mean of diffusion coefficient (a from fitting)
% column4 = SEM fo D
% column5 = mean of alpha (b from fitting)
% column6 = SEM for alpha
% column7 = mode of diffusion

All_model_results = num2cell(All_model_dist(:,5:10));

for f=exist_c
    All_model_results{f,7} = models(f);
end

% %% plot histogram of D
%  if plot_hist==1;
%  figure ('name',['Histogram-D'])
%
% for f=exist_c
%
% subplot(2,2,f)
%
% %%% ploting
% hist(MSDfit_coeff_cl{f}(:,3),50)
%
% %axis([0 axs 0 3]);
% title([char(models(find(All_model_dist(f, :)==1)))]);
%
% end
% axes;
% %h = title([filename]);
% h = title([filename]);
% %h = title([filename '-1']);
% set(gca,'Visible','off');
% set(h,'Visible','on');
%
%         if save_histplot==1;
%             cd /home/davide/R2009b/data/Figures;
%             saveas(gcf,[filename],'fig')
%             %saveas(gcf,[filename '-1'],'fig')
%             print([filename],'-depsc','-r300'); as well as svg -
%             2019-08-22 ZK
%         end
%
%  end
%%
%% analysis  of D
existFrames2=sum(diag(existFrames),1);
D_list=MSD(existFrames2>0,2);
existFrames2=existFrames2(existFrames2>0);
D_mean=sum(D_list.*existFrames2)/sum(existFrames2);

%% save workspace
OBJ_used=parameter.data_type;
clearvars OBJ OBJ2 %this is just to not save it again and reduce file size (already saved in _gui2_steps)
if save_workspace==1
    save ([global_folders.MSDfolder, filesep, filename '-insideMask-workspace'], '-v7.3');
    % save ([global_folders.MSDfolder, filesep, filename '-insideMask-workspace'], 'OBJ_used', 'All_model_dist', 'All_model_results', 'alpha_subD', 'alpha_supD', 'aMSD', 'aMSD2', 'aMSD3', 'axs', 'c', 'c2', 'c_gr_pl', 'classf', 'currentFrame', 'D_list', 'D_mean', 'D_min', 'D_name', 'ddd', 'error', 'exclude_outside_mask', 'exist_c', 'existFrames', 'existFrames2', 'existX', 'f', 'filename', 'Frames', 'h', 'i', 'ind_plot', 'jj', 'loc_err_sigma', 'm', 'maxStepSize', 'meanlife', 'model', 'models', 'MSD', 'MSD2', 'MSD2_pl', 'MSD2clust', 'MSDfit', 'MSDfit_coeff', 'MSDfit_coeff_cl', 'MSDfit_coeff_ori', 'n', 'numFrames', 'objj', 'ObjNum', 'objr', 'OBJsync', 'options', 'pixelSize', 'plot_hist', 'q', 'q25', 'q75', 's', 'save_histplot', 'save_ind_plot', 'save_subplot', 'save_workspace', 'SD', 'selected', 'selected_plot', 'stdMSD2', 'stdMSDfit_coeff', 'step_size_fraction', 'stepNumber', 'stepSize', 'sub_plot', 'timelags', 'timeWindowFraction', 'timeWindowPlot', 'TME', 'TMEsec', 'usealldata', 'xnan', 'xR_selected', 'xR_selected_pl', 'yR_selected', 'yR_selected_pl', '-v7.3');
end
%%
%temporary for Nature revision
% %plot alpha against log10(D)
% figure
% semilogx((MSDfit_coeff(:,1)),(MSDfit_coeff(:,2)),'.','MarkerSize',4)
% xlabel('D')
% ylabel('exponent')
% 
% axis  ([-4 0 0 2.5])
% 
% figure
% hist(log10(MSDfit_coeff(:,1)),-4:0.1:0)
% xlabel('log_{10}(D)')
% ylabel('frequency')
% figure
% hist(MSDfit_coeff(:,2),0:0.1:3)
% xlabel('exponent')
% ylabel('frequency')

%% Generate csv file as well with d and alpha
load ([global_folders.MSDfolder, filesep, filename, '-insideMask-workspace'])
csvwrite ([global_folders.MSDfolder, filesep, filename, '_MSD.csv'], MSDfit_coeff)

close all;
end
