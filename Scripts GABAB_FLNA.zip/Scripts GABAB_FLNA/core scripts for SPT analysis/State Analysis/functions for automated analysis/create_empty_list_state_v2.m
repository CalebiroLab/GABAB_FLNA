% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = create_empty_list_state_v2(movie_name,global_folders)
list_state=struct;
save([global_folders.state_analysis_folder,filesep,movie_name,'_list_state.mat'],'list_state','-v7.3')
clearvars list_state
end

