% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [Ch] = load_data_XY_nocal_v1(movie_name,channel_numbers,parameter,global_folders)
% load data depending on the type of input
channel={'C1','C2','C3','C4'};
parameter.data_type_list={'_gui2_steps.mat','_intmatrix_0pShiftX-0pShiftY-0fShiftT.mat','-C1-C2_OBJswap_after_interaction.mat'};

if strcmp(parameter.data_type,parameter.data_type_list{1})==1
    %% '_gui2_steps.mat'
    cp_ch_sup1=0;
    for ch=channel_numbers
        load([global_folders.rawfolder,filesep,movie_name,'-',channel{1,ch},parameter.data_type_list{1}],'OBJ2')
%         if numel(channel_numbers)>1 && ch>=2
%             if cp_ch_sup1==0
%                 load([global_folders.rawfolder,filesep,char(IFO.calmatrix),'.mat'])
%                 [OBJ2.xR, OBJ2.yR] = transformPointsInverse(t_piecewise_linear{ch}, OBJ2.xR, OBJ2.yR); %transform xy_n to match coordinates into xy_1!!!!!!!!!!!!!!!!
%                 cp_ch_sup1=cp_ch_sup1+1;
%             end
%         end
        Ch(ch).OBJ.xR=OBJ2.xR;
        Ch(ch).OBJ.yR=OBJ2.yR;
        Ch(ch).OBJ.class=OBJ2.class;
        Ch(ch).OBJ.trjRB=OBJ2.trjRB;
    end
elseif strcmp(parameter.data_type,parameter.data_type_list{2})==1
    %% '_intmatrix_0pShiftX-0pShiftY-0fShiftT.mat'
    load([global_folders.rawfolder,filesep,movie_name,'-',channel{1,1},movie_name,'-',channel{1,2},'_intmatrix_0pShiftX-0pShiftY-0fShiftT.mat'])
    load([global_folders.rawfolder,filesep,movie_name,'-',channel{1,1},movie_name,'-',channel{1,2},'_intmatrix2.mat'])
    Ch_old=Ch;
    clearvars Ch
    Ch=struct;
    for ch=channel_numbers
        Ch(ch).OBJ.xR=Ch_old(ch).OBJ.xR;
        Ch(ch).OBJ.yR=Ch_old(ch).OBJ.yR;

        Ch(ch).OBJ.list_compound_int=Ch_old(ch).OBJ3.compound_ints;
        Ch(ch).OBJ.list_compound_start=Ch_old(ch).OBJ3.compound_int_start;
        Ch(ch).OBJ.list_compound_end=Ch_old(ch).OBJ3.compound_int_end;
        Ch(ch).OBJ.int_matrix=int_matrix;
        Ch(ch).OBJ.class=Ch_old(ch).OBJ.class;
    end
elseif strcmp(parameter.data_type,parameter.data_type_list{3})==1
    %% '-C1-C2_OBJswap_after_interaction.mat'
    load([global_folders.rawfolder,filesep,movie_name,'-C1-C2_OBJswap_after_interaction.mat']);


end
end

