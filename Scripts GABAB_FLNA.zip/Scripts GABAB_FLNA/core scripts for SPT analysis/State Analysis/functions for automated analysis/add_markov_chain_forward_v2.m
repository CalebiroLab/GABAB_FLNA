% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_markov_chain_forward_v2(movie_name,channel_number,parameter,global_folders)
% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3','C4'};


n_state=size(parameter.state,1);
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])
list=list_state.state_number;

M=size(list,1);
Mat=zeros(n_state,n_state);
for m=1:M
for n=2:parameter.markov_chain_Nmax
if isnan(list_state.state_number(m,n,1))==0 && isnan(list_state.state_number(m,n-1,1))==0
from=list_state.state_number(m,n-1);
to=list_state.state_number(m,n);

Mat(from,to)=Mat(from,to)+1;
end
end
end
list_state.markov_chain_forward=Mat;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3');
clearvars list_state
end
