% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_istrapped_v9(movie_name,channel_number,parameter,global_folders)
% with swaping
channel={'C1','C2','C3'};

[Ch] = load_data_XY_v1(movie_name,channel_number,parameter,global_folders);

X=Ch(channel_number).OBJ.xR;
Y=Ch(channel_number).OBJ.yR;

load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])%,'list_state')
dataset.X=X;
dataset.Y=Y;
[list_trapped] = Detect_transient_trapping_multiscale(dataset,parameter);

list_state.trapped=list_trapped;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state
end
