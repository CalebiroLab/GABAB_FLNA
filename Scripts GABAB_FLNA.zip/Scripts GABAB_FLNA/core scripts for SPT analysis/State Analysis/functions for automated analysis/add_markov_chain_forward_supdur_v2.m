% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_markov_chain_forward_supdur_v2(movie_name,channel_number,parameter,global_folders)
% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3'};


n_state=size(parameter.state,1);
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])
list_state_number_inter=list_state.state_number;
list_state_number_inter=list_state_number_inter(:,1:parameter.markov_chain_Nmax);
M=size(list_state_number_inter,1);
Mat=zeros(n_state,n_state);
for m=1:M
[state_vector_unique] = make_state_unique_nrep(list_state_number_inter(m,:));
if size(state_vector_unique)>=2
for n=2:size(state_vector_unique,2)
from=state_vector_unique(1,n-1);
to=state_vector_unique(1,n);

%% if both before and after states longer tham parameter.sup_dur
%             if isnan(from)==0 && isnan(to)==0 ...
%                     && ((state_vector_unique(2,n)>=parameter.sup_dur && state_vector_unique(2,n-1)>=parameter.sup_dur)||(from ==1 && state_vector_unique(2,n)>=parameter.sup_dur)||(to==1 && state_vector_unique(2,n-1)>=parameter.sup_dur))
%
%% if either before or after state are longer tha parameter.sup_dur
if isnan(from)==0 && isnan(to)==0 ...
&& ((state_vector_unique(2,n)>=parameter.sup_dur || state_vector_unique(2,n-1)>=parameter.sup_dur)||(from ==1 && state_vector_unique(2,n)>=parameter.sup_dur)||(to==1 && state_vector_unique(2,n-1)>=parameter.sup_dur))

Mat(from,from)=Mat(from,from)+state_vector_unique(2,n-1);

Mat(from,to)=Mat(from,to)+1;
end
end
end
end
list_state.markov_chain_forward_supdur=Mat;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3');
clearvars list_state
end
