% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_on_membrane_v2(movie_name,channel_number,couple_int,parameter,global_folders)

% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3'};
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])
M=size(list_state.exist,1);
N=size(list_state.exist,2);
on_membrane=nan(size(list_state.exist));
if any( strcmp(parameter.state_vec_fields,'interaction'))
on_membrane(list_state.exist==1 | list_state.interaction{couple_int(1),couple_int(2)}==1)=1;
else
on_membrane(list_state.exist==1)=1;
end

for m=1:M
if any(list_state.exist(m,:)==1)
[ List_min_max ] = Make_list_min_max_index_equal(on_membrane(m,:)'==1,1 );
if ~isempty(List_min_max)
for nom=1:size(List_min_max,1)
if List_min_max(nom,1)>1

on_membrane(m,List_min_max(nom,1)-1)=0;
list_state.binary_vec(m,List_min_max(nom,1)-1,:)=-1;
end
if List_min_max(nom,2)<N
on_membrane(m,List_min_max(nom,2)+1)=0;
list_state.binary_vec(m,List_min_max(nom,2)+1,:)=-1;
end
end
end
end
end

list_state.binary_vec(:,:,numel(parameter.state_vec_fields))=on_membrane;
exist_in_cell=list_state.exist;
exist_in_cell(on_membrane==0)=1;
list_state.exist_in_cell=exist_in_cell;
list_state.on_membrane=on_membrane;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state

end
