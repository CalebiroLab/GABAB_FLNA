% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] =  add_CCP_trapping_corrected_v1(movie_name,ch,global_folders)
%COrrection of trapping at CCP
% turns fluctuation in/out cccp while confined to only in CCP
channel={'C1','C2','C3'};

load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,ch},'_list_state.mat'])
%%
for m=1:size(list_state.trapped,1)
[ List_min_max_trapped ] = Make_list_min_max_index_equal( list_state.trapped(m,:)',1 );
if ~isempty(List_min_max_trapped)
for kj=1:size(List_min_max_trapped,1)
[ List_min_max_CCP ] = Make_list_min_max_index_equal( list_state.inCCP(m,List_min_max_trapped(kj,1):List_min_max_trapped(kj,2))',1 );
if size(List_min_max_CCP,1)>1
interval=List_min_max_trapped(kj,1)-1+(List_min_max_CCP(1,1):List_min_max_CCP(end,2));
list_state.inCCP(m,interval)=1;
end
end
end
end
list_state.CCP_trapping_corrected=1;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,ch},'_list_state.mat'],'list_state')
clearvars list_state
end

