% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [list_not_working]=automated_list_of_states_forced_or_not_MLJ(moviename,to_be_computed,test,list_channel,list_interaction_couple,parameter,global_folders)
%input:
% moviename : horizontal cell array where each cell contains a movie name
% ex: moviename={'ZK1001'};
% to_be_computed : input for which parts of the analysis to be calculated 1
% if must be calculated, 0 otherwise
% ex:
% to_be_computed.exist=1;
% to_be_computed.trapped=1;
% to_be_computed.interaction=1;
% to_be_computed.binary_vec=1;
% to_be_computed.on_membrane=1;
% to_be_computed.state_number=1;
% to_be_computed.markov_chain_forward=1;
% to_be_computed.markov_chain_forward_supdur=1;
% test : input for forcing to recalculate some parts of analysis.
% test.forced must be set to 1 to force recalculating
% test.forced=0;
% test.exist=0;
% test.trapped=0;
% test.interaction=0;
% test.binary_vec=0;
% test.on_membrane=0;
% test.state_number=0;
% test.markov_chain_forward=0;
% test.markov_chain_forward_supdur=0;
% list_channel : list of channel for each movie on which to compute the states list_channel=[1,2];
% list_interaction_couple : specifies interaction between which channels [1,2] for interaction between channel 1 and 2, can also be [1,2;1,3] for interaction between 1and 2 and between 1 and 3.
% must be [] if no interactions are calulated
% parameter : structure containing all parameters to be used in format parameter.***
% global_folders : structure containing all folders useful for analysis
% (saving and loading) in format global_folders.***



% with swaping
warning('off','MATLAB:DELETE:FileNotFound')
%%
n=numel(moviename);
channel={'-C1', '-C2', '-C3', '-C4'};
list_of_file={'_gui2_steps.mat','_intmatrix_0pShiftX-0pShiftY-0fShiftT.mat'};
list_not_working={};
nfile=1;
%%

for nmov=1:n
disp(['Loading ',moviename{1,nmov}])

%% remove previous error file for this movie
if isfile([global_folders.state_analysis_folder,filesep,moviename{1,nmov},'_ERROR_list_state.mat'])
delete([global_folders.state_analysis_folder,filesep,moviename{1,nmov},'_ERROR_list_state.mat'])
end
error_movie={};%create emptyy structure for possible errors
%%

path = [global_folders.rawfolder, filesep];
nfile=2;
path_interaction_analysis=[path,moviename{1,nmov},channel{1,1},moviename{1,nmov},channel{1,2}, list_of_file{1,nfile}];


for ch=list_channel
nfile=1;
path_gui2_steps=[path,moviename{1,nmov},channel{1,ch},list_of_file{1,nfile}];

if isfile(path_gui2_steps)==1


movie_name=[moviename{1,nmov},channel{1,ch}];
%% check that file list_state exists, if it doesn't, the cript creates an empty structure and save it
if isfile([global_folders.state_analysis_folder,filesep,movie_name,'_list_state.mat'])==0
try
disp([movie_name, ' creating list of states'])
create_empty_list_state_v2(movie_name,global_folders)
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='create_list';
list_not_working{size(list_not_working,1),3}=e;

error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='create_list';
error_movie{size(error_movie,1),3}=e;


disp([movie_name, ' error with creation of list of states'])
disp(e)
end

else

load([global_folders.state_analysis_folder,filesep,movie_name,'_list_state.mat'])
if exist('list_state','var')==1
disp([movie_name, ' loaded list of states'])
else
disp([movie_name, ' creating list of states'])

create_empty_list_state_v2(movie_name,global_folders)
end
end

%% look at the files to be filled
if test.forced==0
load([global_folders.state_analysis_folder,filesep,movie_name,'_list_state.mat'])

if isfield(list_state,'exist')==0
test.exist=1;
else
test.exist=0;
end

if isfield(list_state,'trapped')==0
test.trapped=1;
else
test.trapped=0;
end

%%
%if
if isfield(list_state,'interaction')==0 && ~isempty(list_interaction_couple) && isfile( path_interaction_analysis)==1
test.interaction=1;
else
test.interaction=0;
end

if isfield(list_state,'on_membrane')==0
test.on_membrane=1;
else
test.on_membrane=0;
end
if isfield(list_state,'binary_vec')==0
test.binary_vec=1;
else
test.binary_vec=0;
end
%  else
%                     test.interaction=0;
%                     test.on_membrane=0;
%                     test.flipped=0;
% end

clearvars list_state
end
%% if the field 'exist' does not exist in the list of state, it is computed
if to_be_computed.exist==1
if test.exist==1
try
disp([movie_name, ' calculating list of exist'])
add_list_exist_min_traj_length_v3(moviename{1,nmov},ch,parameter,global_folders);
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='exist';
list_not_working{size(list_not_working,1),3}=e;

error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='exist';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of exist'])
disp(e)
end

else
%  disp([movie_name,  ' existing list of exist'])
end
end






%% if the field trapped' does not exist in the list of state, it is computed
if to_be_computed.trapped==1
if test.trapped==1
try
disp([movie_name, ' calculating list of istrapped'])
add_list_istrapped_v9(moviename{1,nmov},ch,parameter,global_folders);
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='trapped';
list_not_working{size(list_not_working,1),3}=e;
error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='trapped';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of istrapped'])
disp(e)
end

else
%     disp([movie_name, ' existing list of istrapped'])
end
end



%% if the field 'interaction' does not exist in the list of state, it is computed
% TO DO     
if to_be_computed.interaction==1
if test.interaction==1
for n_couple=1:size(list_interaction_couple,1)
try
disp([movie_name, ' calculating list of interactions'])
add_list_interaction_v4(moviename{1,nmov},ch,list_interaction_couple(n_couple,:),parameter,global_folders);
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}=['interaction C',num2str(list_interaction_couple(n_couple,1)),' C',num2str(list_interaction_couple(n_couple,2))];
list_not_working{size(list_not_working,1),3}=e;
error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='interaction';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of interaction'])
disp(e)
end
end
end
end




%% if the field 'flipped' does not exist in the list of state, it is computed
if to_be_computed.binary_vec==1
if test.binary_vec==1
try
disp([movie_name, ' calculating list of flipped states'])
add_list_binary_vec_v1(moviename{1,nmov},ch,list_interaction_couple,parameter,global_folders);
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='flipped';
list_not_working{size(list_not_working,1),3}=e;
error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='flipped';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of flipped'])
disp(e)
end

else
%        disp([movie_name, ' existing list of flipped states'])
end
end
%% if the file 'on_membrane' does not exist in the list of state, it is computed


if to_be_computed.on_membrane==1
if test.on_membrane==1
try
disp([movie_name, ' calculating list of on_membrane'])
add_list_on_membrane_v2(moviename{1,nmov},ch,list_interaction_couple,parameter,global_folders)
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='on_membrane';
list_not_working{size(list_not_working,1),3}=e;
error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='on_membrane';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of on_membrane'])
disp(e)
end

else
%         disp([movie_name, ' existing list of on_membrane'])
end
end

end
end
%     if isfile( path_interaction_analysis)==1
%         
for ch=list_channel
path_gui2_steps=[path,moviename{1,nmov},channel{1,ch},list_of_file{1,nfile}];

if isfile(path_gui2_steps)==1
movie_name=[moviename{1,nmov},channel{1,ch}];
if isfile([global_folders.state_analysis_folder,filesep,movie_name,'_list_state.mat'])==1
if  test.forced==0



load([global_folders.state_analysis_folder,filesep,movie_name,'_list_state.mat'])
if isfield(list_state,'state_number')==0
test.state_number=1;
else
test.state_number=0;
end
if isfield(list_state,'markov_chain_forward')==0
test.markov_chain_forward=1;
else
test.markov_chain_forward=0;
end
if isfield(list_state,'markov_chain_forward_supdur')==0
test.markov_chain_forward_supdur=1;
else
test.markov_chain_forward_supdur=0;
end
clearvars list_state

end
%% if the field 'state_number' does not exist in the list of state, it is computed

if to_be_computed.state_number==1
if test.state_number==1
try
disp([movie_name, ' calculating list of state_numbers'])
add_list_state_number_v7(moviename{1,nmov},ch,list_interaction_couple,parameter,global_folders);
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='state_number';
list_not_working{size(list_not_working,1),3}=e;
error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='state_number';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of state_number'])
disp(e)
end

else
%           disp([movie_name, ' existing list of state_numbers'])
end
end
%             %% if the field 'state_number_modified' does not exist in the list of state, it is computed
%
%             if test.state_number_modified==1
%                 try
%                     modify_list_state_number_v1(moviename{1,nmov},ch,parameter);
%                     disp([movie_name, ' added list of state_number_modified'])
%                 catch e
%                     list_not_working{size(list_not_working,1)+1,1}=movie_name;
%                     list_not_working{size(list_not_working,1),2}='state_number_modified';
%                     list_not_working{size(list_not_working,1),3}=e;
%                     disp([movie_name, ' error with calculation of state_number_modified'])
%                     disp(e)
%                 end
%
%             else
%                 disp([movie_name, ' existing list of state_numbers'])
%             end
%% add forward markov chain

if to_be_computed.markov_chain_forward==1
if test.markov_chain_forward==1
try
disp([movie_name, ' calculating markov_chain_forward'])
add_markov_chain_forward_v2(moviename{1,nmov},ch,parameter,global_folders)
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='markov_chain_forward';
list_not_working{size(list_not_working,1),3}=e;
error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='markov_chain_forward';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of markov_chain_forward'])
disp(e)
end

else
%           disp([movie_name, ' existing markov_chain_forward'])
end
end
if to_be_computed.markov_chain_forward_supdur==1

if test.markov_chain_forward_supdur==1
try
disp([movie_name, ' calculating markov_chain_forward_supdur'])
add_markov_chain_forward_supdur_v2(moviename{1,nmov},ch,parameter,global_folders)
catch e
list_not_working{size(list_not_working,1)+1,1}=movie_name;
list_not_working{size(list_not_working,1),2}='markov_chain_forward_supdur';
list_not_working{size(list_not_working,1),3}=e;
error_movie{size(error_movie,1)+1,1}=movie_name;
error_movie{size(error_movie,1),2}='markov_chain_forward_supdur';
error_movie{size(error_movie,1),3}=e;
disp([movie_name, ' error with calculation of markov_chain_forward_supdur'])
disp(e)
end

else
%           disp([movie_name, ' existing markov_chain_forward_supdur'])
end
end
end
%  end
end
end
if ~isempty(error_movie)==1
save([global_folders.state_analysis_folder,filesep,moviename{1,nmov},'_ERROR_list_state.mat'],'error_movie')
end
end

