% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_exist_min_traj_length_v3(movie_name,channel_number,parameter,global_folders)
% with swaping

% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3'};
%% load interaction file
[Ch] = load_data_XY_v1(movie_name,channel_number,parameter,global_folders);

list_exist=~isnan(Ch(channel_number).OBJ.xR(:,:));
list_exist(sum(double(list_exist),2)<parameter.min_traj_length,:)=0;

%% remove part of trajectories outside movie
name_msk=[movie_name,'-',channel{1,channel_number},'_msk'];
image_msk=double(imread ([global_folders.rawfolder,filesep,name_msk,'.tif']));
image_msk(image_msk>0)=1;
int_x=floor(Ch(channel_number).OBJ.xR);
int_y=floor(Ch(channel_number).OBJ.yR);

%% remove eventual points outside camera
list_exist(int_x<1)=0;
list_exist(int_y<1)=0;
list_exist(int_x>size(image_msk,2))=0;
list_exist(int_y>size(image_msk,1))=0;

%% find those inside msk
list_in_msk=zeros(size(list_exist));
list_in_msk(list_exist)=double(image_msk(sub2ind(size(image_msk),int_y(list_exist),int_x(list_exist))))==1;
list_exist(list_in_msk==0)=0;

%% load list_state and append the exist matrix
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])
list_state.exist=list_exist;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')

clearvars list_state
end
