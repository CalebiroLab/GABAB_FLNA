% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_interaction_v4(movie_name,channel_number,couple_int,parameter,global_folders)
% add swapping
couple_int=sort(couple_int);
channel={'C1','C2','C3','C4'};
%% come back to raw folder
% shiftX=0;
% shiftY=0;
% shiftT=0;
% load([movie_name,'-',channel{1,couple_int(1)},movie_name,'-',channel{1,couple_int(2)},'_intmatrix_' num2str(shiftX) 'pShiftX-' num2str(shiftY) 'pShiftY-' num2str(shiftT) 'fShiftT']);
% load([movie_name,'-',channel{1,couple_int(1)},movie_name,'-',channel{1,couple_int(2)},'_intmatrix2']);
[Ch] = load_data_XY_v1(movie_name,couple_int,parameter,global_folders);
%%
list_interact_ch1=zeros(size(Ch(1).OBJ.xR,1),size(Ch(1).OBJ.xR,2));
list_interact_ch2=zeros(size(Ch(2).OBJ.xR,1),size(Ch(2).OBJ.xR,2));

list_interact_all_partner_ch1=cell(size(Ch(1).OBJ.xR,1),size(Ch(1).OBJ.xR,2));
list_interact_all_partner_ch2=cell(size(Ch(2).OBJ.xR,1),size(Ch(2).OBJ.xR,2));
list_compound_idx_ch1=cell(size(Ch(1).OBJ.xR,1),size(Ch(1).OBJ.xR,2));
list_compound_idx_ch2=cell(size(Ch(2).OBJ.xR,1),size(Ch(2).OBJ.xR,2));
%% run through trajectories
N=size(Ch(1).OBJ.xR,2);
Long_int_list=1:numel(Ch(1).OBJ.list_compound_int);
for ch=couple_int
Ch(ch).OBJ.list_compound_durations=Ch(ch).OBJ.list_compound_end-Ch(ch).OBJ.list_compound_start+1;
end

%% search interactions
for n_comp=1:numel(Long_int_list)
compInt=Long_int_list(n_comp);
%%% define trajectory before and after interaction
%% pre_trj

[~,int_start_idx]=min(Ch(ch).OBJ.int_matrix(Ch(1).OBJ.list_compound_int{compInt},1));
int_numb_start=Ch(1).OBJ.list_compound_int{compInt}(int_start_idx); %% the first 'interaction number' in 'compound_ints'
compound_start_frame=Ch(ch).OBJ.int_matrix(int_numb_start,1);                           %% frame at which interaction starts
preObj_ch1=Ch(ch).OBJ.int_matrix(int_numb_start,4);                        %% Ch1 object at which interaction starts
preObj_ch2=Ch(ch).OBJ.int_matrix(int_numb_start,8);                        %% Ch2 object at which interaction starts

%% post_trj
%int_numb_end=max(Ch(1).OBJ.list_compound_int(1,compInt).ints);   %% the last 'interaction number' in 'compound_ints'
[~,int_end_idx]=max(Ch(ch).OBJ.int_matrix(Ch(1).OBJ.list_compound_int{compInt},2));
int_numb_end=Ch(1).OBJ.list_compound_int{compInt}(int_end_idx); %% the first 'interaction number' in 'compound_ints'

compound_end_frame=Ch(ch).OBJ.int_matrix(int_numb_end,2);                          %% frame at which interaction ends
postObj_ch1=Ch(ch).OBJ.int_matrix(int_numb_end,4);                         %% Ch1 object at which interaction ends
postObj_ch2=Ch(ch).OBJ.int_matrix(int_numb_end,8);                         %% Ch2 object at which interaction ends

%% write 1 when the particle is interacting
list_interact_ch1(preObj_ch1,compound_start_frame:compound_end_frame)=1;
list_interact_ch2(preObj_ch2,compound_start_frame:compound_end_frame)=1;
%% write the idx of partners on the other channel when the particle is colocalising
list_interact_all_partner_ch1(preObj_ch1,compound_start_frame:compound_end_frame)=cellfun(@(x)[x,preObj_ch2], list_interact_all_partner_ch1(preObj_ch1,compound_start_frame:compound_end_frame),'UniformOutput',false);
list_interact_all_partner_ch2(preObj_ch2,compound_start_frame:compound_end_frame)=cellfun(@(x)[x,preObj_ch1], list_interact_all_partner_ch2(preObj_ch2,compound_start_frame:compound_end_frame),'UniformOutput',false);

list_compound_idx_ch1(preObj_ch1,compound_start_frame:compound_end_frame)=cellfun(@(x)[x,n_comp],list_compound_idx_ch1(preObj_ch1,compound_start_frame:compound_end_frame),'UniformOutput',false);
list_compound_idx_ch2(preObj_ch2,compound_start_frame:compound_end_frame)=cellfun(@(x)[x,n_comp],list_compound_idx_ch2(preObj_ch2,compound_start_frame:compound_end_frame),'UniformOutput',false);


% list_interact_partner_ch1{preObj_ch1,compound_start_frame:compound_end_frame}=preObj_ch2;
%   list_interact_partner_ch2{preObj_ch2,compound_start_frame:compound_end_frame}=preObj_ch1;

end

%% reordering the interaction partners from longest to shortest interaction compound
list_interact_all_partner_ch1=cellfun(@(x,y) order_by_compound_duration(x,y,Ch(1).OBJ.list_compound_durations), list_interact_all_partner_ch1,list_compound_idx_ch1,'UniformOutput',false);
list_interact_all_partner_ch2=cellfun(@(x,y) order_by_compound_duration(x,y,Ch(1).OBJ.list_compound_durations), list_interact_all_partner_ch2,list_compound_idx_ch2,'UniformOutput',false);
list_interact_partner_ch1=cellfun(@(x)find_first_or_empty(x),list_interact_all_partner_ch1);%,'UniformOutput',false);
list_interact_partner_ch2=cellfun(@(x)find_first_or_empty(x),list_interact_all_partner_ch2);%,'UniformOutput',false);

load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])%,'list_state')
if channel_number==couple_int(1)
list_state.interaction{couple_int(1),couple_int(2)}=list_interact_ch1;
% list_state.interaction(~list_state.exist)=nan;
list_state.interaction_partner{couple_int(1),couple_int(2)}=list_interact_partner_ch1;
%   list_state.interaction_all_partner{couple_int(1),couple_int(2)}=list_interact_all_partner_ch1;

%list_state.interaction_partner(~list_state.exist)=nan;
elseif channel_number==couple_int(2)
list_state.interaction{couple_int(1),couple_int(2)}=list_interact_ch2;
% list_state.interaction(~list_state.exist)=nan;
list_state.interaction_partner{couple_int(1),couple_int(2)}=list_interact_partner_ch2;
%  list_state.interaction_all_partner{couple_int(1),couple_int(2)}=list_interact_all_partner_ch2;
%list_state.interaction_partner(~list_state.exist)=nan;
end
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state

end

function [interact_partner_ordered]=order_by_compound_duration(interact_partner,compound_list,compound_duration_list)
if numel(compound_list)>1
[~,idx_sort]=sort(compound_duration_list(compound_list),'descend');
interact_partner_ordered=interact_partner(idx_sort);
else
interact_partner_ordered=interact_partner;    
end
end

function result=find_first_or_empty(x)
if ~isempty(x)
result=x(1);
else
result=nan;
end
end
