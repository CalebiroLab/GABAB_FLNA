% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_state_number_v7(movie_name,channel_number,couple_int,parameter,global_folders)
% add the possibility to change list_state_variables for state_calculations
%Trying with everything in the same line
% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3','C4'};
n_state=size(parameter.state,1);
if ~isempty(couple_int)
list_channel=couple_int;
if channel_number==couple_int(1)
other_channel=couple_int(2);
elseif channel_number==couple_int(2)
other_channel=couple_int(1);
end

else
list_channel=channel_number;
end
interaction_pos=find(ismember(parameter.state_vec_fields,'interaction'));

for ch=list_channel
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,ch},'_list_state.mat'])
list_state_ch{ch}=list_state;
%% store binary_vec in list for both channels
for n_state_dim=1:numel(parameter.state_vec_fields)
inter=list_state.binary_vec(:,:,n_state_dim);
list{1,ch}(:,n_state_dim)=reshape(double(inter)',[],1);
end

%
if ~isempty(couple_int)
if ch==channel_number
M=size(list_state.on_membrane,1);
N=size(list_state.on_membrane,2);
mem_keep=list_state.on_membrane;
elseif ch==other_channel
M_other_channel=size(list_state.on_membrane,1);
N_other_channel=size(list_state.on_membrane,2);
end
else
M=size(list_state.on_membrane,1);
N=size(list_state.on_membrane,2);
mem_keep=list_state.on_membrane;
end

end


%% translating interaction partner from subscript to indices
if ~isempty(couple_int)
test= list_state_ch{channel_number}.interaction_partner{couple_int(1),couple_int(2)};
test2=N*(test-1)+repmat(1:N_other_channel,M,1);
list_interaction_partner_ind=reshape(test2',[],1);
end



list_state_number=nan(M,N);
list_state_number_ind=reshape( list_state_number',[],1);

% flipped :> CCP | istrapped | interaction | on membrane
List_N=1:size(list{1,channel_number},1);
List_N=List_N(1,list{1,channel_number}(:,interaction_pos)==1);
%% get state vector of partner for interaction
list_not_exist_sub=isnan(mem_keep);
list_not_exist_ind2=reshape(list_not_exist_sub',[],1);
list_state_number_inter=nan(sum(~list_not_exist_ind2),1);
list{1,channel_number}(list_not_exist_ind2,:)=[];
if ~isempty(couple_int) 
state_partner=nan(N*M,numel(parameter.state_vec_fields));
%if~isempty(List_N)
list_int_not_exist_ind=isnan(list_interaction_partner_ind);
list_interaction_partner_ind(list_int_not_exist_ind)=[];
state_partner(List_N',:)=list{1,other_channel}(list_interaction_partner_ind,:);
state_partner(list_not_exist_ind2,:)=[];
%end
    
end

%%  set state number
for state_num=1:n_state
    %     disp(num2str(state_num))
    for  n_sub_state=1:numel(parameter.state{state_num,2})   %%%%%%%%%%%%%%%%%%% for each state associate to a state number%%%%%%%%%%%
        if ~isempty(couple_int)
            
            if parameter.state{state_num,2}{n_sub_state}(interaction_pos,1)==1 %&& ~isempty(List_N)
                list_found_ch1=ismember(list{1,channel_number},parameter.state{state_num,2}{n_sub_state}','rows');
                list_found_ch2=ismember(state_partner,parameter.state{state_num,3}{n_sub_state}','rows');
                list_state_number_inter(list_found_ch1 & list_found_ch2,1)=state_num;
            else
                list_found=ismember(list{1,channel_number},parameter.state{state_num,2}{n_sub_state}','rows');
                list_state_number_inter(list_found'==1,1)=state_num;
            end
        else
            list_found=ismember(list{1,channel_number},parameter.state{state_num,2}{n_sub_state}','rows');
            list_state_number_inter(list_found'==1,1)=state_num;
        end
    end
end
list_state_number_ind(~list_not_exist_ind2)=list_state_number_inter;
list_state_number=reshape(list_state_number_ind,N,M)';
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])
list_state.state_number=list_state_number;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state
end
