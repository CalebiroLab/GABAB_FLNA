% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [inmask] = is_inmask_v1(X,Y,mask)
% 
mask=mask>0;
inmask=false(size(X,1),size(X,2));
list_exist=~isnan(X) & ~isnan(Y);
X=floor(X);
Y=floor(Y);
inmask(list_exist(:))=(mask(sub2ind(size(mask),Y(list_exist(:)),X(list_exist(:)))));
    
end

