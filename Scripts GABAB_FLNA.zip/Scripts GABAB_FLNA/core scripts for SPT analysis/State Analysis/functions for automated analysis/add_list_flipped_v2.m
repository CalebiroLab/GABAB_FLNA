% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_flipped_v2(movie_name,channel_number,parameter,global_folders)

% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3'};
%% load list_state
cd(global_folders.state_analysis_folder)
load([movie_name,'-',channel{1,channel_number},'_list_state.mat'])
n_meas_tot=2;
list=zeros(size(list_state.exist,1),parameter.FrameNumber,3);
list(:,:,1)=double(list_state.inCCP(:,1:parameter.FrameNumber));
list(:,:,2)=double(list_state.trapped(:,1:parameter.FrameNumber));

list=list(:,:,parameter.selected_states==1);
N=size(list,2);
M=size(list,1);
for meas=1:n_meas_tot
for m=1:M

if sum(list_state.exist(m,:))>parameter.minimal_state_duration
[list(m,list_state.exist(m,:),meas)] = flipping_state(list(m,list_state.exist(m,:),meas),parameter.minimal_state_duration);
end
end
end
list(:,:,3)=double(list_state.interaction(:,1:parameter.FrameNumber));
% list(:,:,4)=double(list_state.on_membrane);

list_state.flipped=list;
save([movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state
end
