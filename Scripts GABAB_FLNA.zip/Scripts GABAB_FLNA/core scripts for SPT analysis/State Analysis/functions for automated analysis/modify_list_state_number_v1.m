% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = modify_list_state_number_v1(movie_name,channel_number,parameter,global_folders)
global_folders_YL;
% changes state numbers according to parameter.merging_state
% parameter.merging_state{n,1} => target state
% parameter.merging_state{n,2} => list of states to be reassigned as being the target state
channel={'C1','C2','C3'};
n_state=size(parameter.state,1);
if channel_number==1
other_channel=2;
elseif channel_number==2
other_channel=1;
end
%% load list_state
cd(global_folders.state_analysis_folder)
load([movie_name,'-',channel{1,channel_number},'_list_state.mat'])
list_state_number_modified=list_state.state_number;
if ~isempty(parameter.merging_state)
for n=1:size(parameter.merging_state,1)
for n_state_to_modify=parameter.merging_state{n,2}
list_state_number_modified(list_state_number_modified==n_state_to_modify)=parameter.merging_state{n,1};
end
end
end
list_state.state_number_modified=list_state_number_modified;
save([movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state
end
