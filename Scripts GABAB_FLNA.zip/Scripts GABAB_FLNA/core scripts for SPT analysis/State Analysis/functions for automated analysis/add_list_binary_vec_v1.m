% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_binary_vec_v1(movie_name,channel_number,couple_int,parameter,global_folders)

% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3','C4'};
%% load list_state
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])

list=zeros(size(list_state.exist,1),size(list_state.exist,2),numel(parameter.state_vec_fields)-1);
for n_dim=1:numel(parameter.state_vec_fields)-1
if strcmp(parameter.state_vec_fields{n_dim},'interaction')
list(:,:,n_dim)=double(list_state.(parameter.state_vec_fields{n_dim}){couple_int(1),couple_int(2)});
else
list(:,:,n_dim)=double(list_state.(parameter.state_vec_fields{n_dim}));    
end
end

list_state.binary_vec=list;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state
end
