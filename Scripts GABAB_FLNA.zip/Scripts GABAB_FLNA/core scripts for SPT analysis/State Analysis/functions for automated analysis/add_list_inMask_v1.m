% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = add_list_inMask_v1(movie_name,channel_number,state_name,parameter,global_folders)
% with swaping
% Load the CCP movie then filter using Kalman filter then deconvolve with theoretical PSF then threshold is applied, the threshgolded images are time averaged such that only persistent pixels are 'real CCP pixels'
% Take the already shifted coordinates and generates binary matrix where  is when molecule position overlays the CCP mask

% colocalization of species in three different channels
% with update of CCP each frame
channel={'C1','C2','C3','C4'};

state_index=find (ismember(parameter.mask_pairs(:,1),state_name));% find the line corresponding to state_name in parameter.mask_pairs
%% load list_state
load([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'])
%% load calibatrion matrix
if ~isnan(parameter.mask_pairs{state_index,3})
load([global_folders.rawfolder,filesep,movie_name,'-',channel{1,channel_number},'_gui2_steps.mat'],'IFO')
load([global_folders.rawfolder,filesep,char(IFO.calmatrix),'.mat'])
clearvars OBJ OBJ2
end
[Ch] = load_data_XY_v1(movie_name,channel_number,parameter,global_folders);

%% load mask

Filename=[movie_name,parameter.mask_pairs{state_index,2}];
if strcmp(parameter.mask_pairs{state_index,2}(end-3:end),'.tif')
InfoImage=imfinfo([global_folders.rawfolder,filesep,Filename]);
mImage=InfoImage(1).Width;
nImage=InfoImage(1).Height;
stack_binary=zeros(nImage,mImage,numel(InfoImage));
TifLink = Tiff([global_folders.rawfolder,filesep,Filename], 'r');
for i=1:numel(InfoImage)
TifLink.setDirectory(i);
stack_binary(:,:,i)=TifLink.read();
end
TifLink.close();
elseif strcmp(parameter.mask_pairs{state_index,2}(end-3:end),'.mat')

load([global_folders.rawfolder,filesep,Filename]);% loads 'stack_binary_CCP'
stack_binary=stack_binary_CCP;
clearvars stack_binary_CCP
end

%load([global_folders.rawfolder,filesep,movie_name,'_actin_msk2.mat']);% loads 'stack_binary_CCP'

%% round trajectory coordinates
int_x=floor(Ch(channel_number).OBJ.xR);
int_y=floor(Ch(channel_number).OBJ.yR);

%% Pre-Allocate memory for list in Mask
list_in_msk=nan(size(list_state.exist));
%% loop for aligning Mask image and calculating colocalisation at each frame

if size(stack_binary,3)==1
if ~isnan(parameter.mask_pairs{state_index,3})

im_toshow_aligned=imwarp(stack_binary(:,:),t_piecewise_linear_rev{parameter.mask_pairs{state_index,3}},'OutputView', imref2d(size(stack_binary(:,:))));
else
im_toshow_aligned=stack_binary(:,:);%imwarp(stack_binary(:,:),t_piecewise_linear_rev{3},'OutputView', imref2d(size_im));
end
list_in_msk(list_state.exist(:))=double(stack_binary(sub2ind(size(stack_binary),int_y(list_state.exist(:)),int_x(list_state.exist(:)))));
list_in_msk(~list_state.exist==1)=nan;
else
size_im=size(stack_binary(:,:,1));
for frame=1:size(int_x,2)
%% aligning the image
if ~isnan(parameter.mask_pairs{state_index,3})
im_toshow_aligned=imwarp(stack_binary(:,:,frame),t_piecewise_linear_rev{parameter.mask_pairs{state_index,3}},'OutputView', imref2d(size_im));
else
im_toshow_aligned=stack_binary(:,:,frame);%imwarp(stack_binary(:,:,frame),t_piecewise_linear_rev{3},'OutputView', imref2d(size_im));
end
%% localisation on CCP: 1 if on CCP, 0 if outside
list_in_msk(list_state.exist(:,frame),frame)=double(im_toshow_aligned(sub2ind(size(im_toshow_aligned),int_y(list_state.exist(:,frame),frame),int_x(list_state.exist(:,frame),frame))));
end
end
list_state.(state_name)=list_in_msk;
save([global_folders.state_analysis_folder,filesep,movie_name,'-',channel{1,channel_number},'_list_state.mat'],'list_state','-v7.3')
clearvars list_state
end

