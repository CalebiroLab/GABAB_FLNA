% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function OBJ_swapping_cycle_YL_v2 (movie_list,parameter, global_folders)
close all;
movie_fields=fieldnames(movie_list);
for n_group=1:numel(movie_fields)
group=movie_fields{n_group};
moviename = movie_list.(group);
disp ([movie_fields{n_group,1}, ' OK']);
moviename = movie_list.(group);
for n_mov=1:numel(moviename)
for n_couple=1:size( parameter.list_interaction_couple,1)
automated_swapping (moviename{n_mov},  parameter.list_interaction_couple(n_couple,:), global_folders);
end
end
end


end

%%
function automated_swapping (mov_name,interaction_couple, global_folders)

list_of_file={['-C',num2str(interaction_couple(1)),'-C',num2str(interaction_couple(2)),'_OBJswap_after_interaction.mat']};
list_not_working={};
nfile=1;
%for ch=1:2
path = [global_folders.rawfolder, filesep];
entire_path=[path, mov_name, list_of_file{1,nfile}];
if exist(entire_path)~= 0
disp ([mov_name,' OK ', list_of_file{1,nfile}]); %this checks if each file with the given category (e.g. gui2 steps, MSD.csv, .avi) exist and displays OK if it does
else
try
disp ([mov_name,' NO ', list_of_file{1,nfile}])
disp ('Calculating...')
save_file_name=[global_folders.rawfolder, filesep, mov_name,'-C',num2str(interaction_couple(1)),'-C',num2str(interaction_couple(2)),'_OBJswap_after_interaction.mat'];
[Ch] = OBJ_swap_after_interaction_v2(mov_name,interaction_couple, global_folders);
save(save_file_name,'Ch','-v7.3')
catch e
list_not_working{size(list_not_working,1)+1,1}=mov_name;
list_not_working{size(list_not_working,1),2}=list_of_file{1,nfile};
list_not_working{size(list_not_working,1),3}=e;
save ([global_folders.rawfolder, filesep, mov_name, '_OBJ_swapping_not_working'], 'list_not_working');
end
end

end

