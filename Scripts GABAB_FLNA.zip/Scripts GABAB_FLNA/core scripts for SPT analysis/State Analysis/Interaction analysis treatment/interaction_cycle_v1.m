% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function interaction_cycle_YL_v1 (movie_list,parameter, global_folders)
close all;
movie_fields=fieldnames(movie_list);
for n_group=1:numel(movie_fields)
group=movie_fields{n_group};
disp ([movie_fields{n_group}, ' OK']);
moviename =movie_list.(group);
for n_mov=1:numel(moviename)
for n_couple=1:size( parameter.list_interaction_couple,1)
automated_interaction(moviename{n_mov}, parameter.frame_number_interaction_analysis, parameter.searchRadius, parameter.list_interaction_couple(n_couple,:), global_folders);
end
end
end
end

function automated_interaction (movie_name, FrameNumber, searchradius,interaction_couple, global_folders)
warning('off','MATLAB:DELETE:FileNotFound')
% channel={'-C1', '-C2'};
list_of_file={'_intmatrix2.mat'};
nfile=1;
list_not_working={};

% for ch=1:2
path = [global_folders.rawfolder, filesep];
mov_name=[movie_name,'-C',num2str(interaction_couple(1))];
mov_name_combined=[movie_name,'-C',num2str(interaction_couple(1)), movie_name,'-C',num2str(interaction_couple(2))];
entire_path=[path,mov_name_combined, list_of_file{1,nfile}];

if isfile([global_folders.rawfolder, filesep, mov_name, '_interaction_not_working.mat'])
delete([global_folders.rawfolder, filesep, mov_name, '_interaction_not_working.mat'],'list_not_working')
end

if exist(entire_path)~= 0
disp ([mov_name_combined,' OK ', list_of_file{1,nfile}]);
else
if strcmp(list_of_file{1,nfile},'_intmatrix2.mat')==1
disp ([mov_name_combined,' NO intmatrix2'])
try
load ([global_folders.rawfolder, filesep, mov_name, '_gui2_steps'],'IFO'); %to get the calmatrix date
calmatrix_for_interaction=convertStringsToChars(IFO.calmatrix);
if IFO.numFrames<FrameNumber
FrameNumber=IFO.numFrames;
end
clearvars IFO OBJ OBJ2 TME;

%% These are just to get the proper variable names from the movie files
TrackedFile_length=strlength(mov_name);
author_initial=string(extractBetween(mov_name, 1,2));
movienumber_without_initial=string(erase(mov_name, author_initial));
movienumber_without_initial_length=length(char(movienumber_without_initial));
Channel_characters=movienumber_without_initial_length-3;
movienumber_without_initialandchannel=string(extractBetween(movienumber_without_initial, 1, Channel_characters));
channel_letters=string(erase(movienumber_without_initial, movienumber_without_initialandchannel));
movienumber_with_initial=char(erase(mov_name, channel_letters));
disp ('Calculating interaction...')
interaction_v2_YL(movienumber_with_initial, searchradius, FrameNumber,interaction_couple, calmatrix_for_interaction, global_folders);
% B=cell(); %to test for error
catch e
    disp(e)
list_not_working{size(list_not_working,1)+1,1}=mov_name;
list_not_working{size(list_not_working,1),2}=list_of_file{1,nfile};
list_not_working{size(list_not_working,1),3}=e;
save([global_folders.rawfolder, filesep, mov_name, '_interaction_not_working'], 'list_not_working');
end
end
end

end
