% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [list_error]=swap_after_interaction_movie_list_v1(movie_name_list,global_folders)
channel1={'C1', 'C2'};
interaction_file_extension1='_intmatrix_0pShiftX-0pShiftY-0fShiftT.mat';
path1 = [global_folders.rawfolder, filesep];
list_error={};
for n_mov=1:numel(movie_name_list)
path_interaction_analysis1=[global_folders.rawfolder,filesep,movie_name_list{n_mov},'-',channel1{1,1},movie_name_list{n_mov},'-',channel1{1,2}, interaction_file_extension1];
save_file_name=[global_folders.rawfolder,filesep,movie_name_list{n_mov},'-C1-C2_OBJswap_after_interaction.mat'];
if isfile(path_interaction_analysis1) && ~isfile(save_file_name)
disp([movie_name_list{n_mov},' computing'])

tic
try
[Ch] = OBJ_swap_after_interaction_v1(movie_name_list{n_mov},global_folders);    
save(save_file_name,'Ch','-v7.3')
catch e
list_error{size(list_error,1)+1,1}=movie_name_list{n_mov};
list_error{size(list_error,1),2}=e;

disp(['ERROR ',movie_name_list{n_mov}])
disp(e)
end
toc

elseif ~isfile(path_interaction_analysis1) 
disp([movie_name_list{n_mov},' no interaction file'])
elseif  isfile(save_file_name)
disp([movie_name_list{n_mov},' ok'])
end
end
end
