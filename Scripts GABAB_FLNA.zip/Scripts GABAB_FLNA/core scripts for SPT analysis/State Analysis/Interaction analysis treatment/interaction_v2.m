% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function interaction_v2_YL(FileName, searchradius, FrameNumber,interaction_couple, calibrationFile, global_folders)
% global_folders

Channel_1=[FileName,'-C',num2str(interaction_couple(1))];
Channel_2=[FileName,'-C',num2str(interaction_couple(2))];
tic
Star_interact_8v4_YL ({Channel_1,Channel_2}, searchradius, calibrationFile, [0], [0], [0], 1, FrameNumber, global_folders);
toc
%% Get the duration of the interaction in csv file
combined_name=strcat(Channel_1, Channel_2);
load ([global_folders.rawfolder, filesep, combined_name, '_intmatrix2'])
int_length = transpose(extractfield(shift,'compound_ints_durations'));
csvwrite ([global_folders.rawfolder, filesep, combined_name, '_interaction_duration.csv'], int_length)
clearvars shift frame_num;

%% Visualizations
% if visualize=='v'
% starshow_4D_fast_5v0_ZK({Channel_C1 Channel_C2}, calibrationFile, 1, FrameNumber,[], [], [], [], [1], [], [1 2]) % just two movies overlaid
% % starshow_2ch_ints_4v1_ZK({Channel_C1 Channel_C2}, 1 , FrameNumber, [], [],[],[],[], 8, 1,0,0,1, 0.2, 0.999, 1) % just has trajectories (plus interactions) overlaid
% % starshow_2ch_ints_4v1_ZK({Channel_C1 Channel_C2}, 1 , FrameNumber, [], [],[],[],[], 8, 1,1,0,1, 0.2, 0.999, 1) % show with movie
% end
close all force;
end
