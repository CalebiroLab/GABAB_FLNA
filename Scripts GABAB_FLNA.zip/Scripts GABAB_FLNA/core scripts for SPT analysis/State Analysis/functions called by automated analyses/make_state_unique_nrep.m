% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [state_vector_unique] = make_state_unique_nrep(state_vector)

% Transform a row vector of state numbers  in a two row vector
% first vetor is the states within the vector wihtout consecutive repetitions
% second vector is the number of repetition of the given state

% index=1;
% state_vector_unique=[];
% while index<=size(state_vector,2)
% [pos_up] = find_index_equal_wrap_right( index,state_vector',state_vector(1,index));
% state_vector_unique=[state_vector_unique,[state_vector(1,index);pos_up-index+1]];
% index=pos_up+1;
% end

 index=1;
state_vector_unique=nan(2,numel(state_vector));
cp_svu=0;
while index<=size(state_vector,2)
cp_svu=cp_svu+1;
    [pos_up] = find_index_equal_wrap_right( index,state_vector',state_vector(1,index));
state_vector_unique(:,cp_svu)=[state_vector(1,index);pos_up-index+1];
index=pos_up+1;
end

if cp_svu<numel(state_vector)
    state_vector_unique(:,cp_svu+1:end)=[];
end


function [pos_up] = find_index_equal_wrap_right( index,Vector_to_test,quantity)
% Return min and max index equal of result where vector_to_test==quantity
% quantity default value is 1
% 0 0 0    1      1   1   1 1   1 0  0 0
%       pos_down    index    pos_up
%Testing continuous path
N=size(Vector_to_test,1);
% if nargin==2
%     quantity=1;
% end
stop_up=0;
pos_up=index;
while stop_up==0
if stop_up==0
if pos_up+1<=N
if Vector_to_test(pos_up+1,1)==quantity
pos_up=pos_up+1;
else
stop_up=1;
end
else
stop_up=1;
end
end
% 
%     if stop_up==1
%         break
%     end
end
end



end

