% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [new_state_list] = flipping_state(new_state_list,state_dur)
N=size(new_state_list,2);
for stage=1%:2
% stage 1 flips stages that are in between two states at least as long as state_dur
% stage 2 flips stages that are in between two states where the sum of duration of neighboring states is at least state_dur
stop=0;
iter=0;
while stop==0
iter=iter+1;
%% extracting states 1 and 0
[ List_0 ] = Make_list_min_max_index_equal( new_state_list',0 );
[ List_1 ] = Make_list_min_max_index_equal( new_state_list',1 );
List_0=[List_0,zeros(size(List_0,1),1)];
List_1=[List_1,ones(size(List_1,1),1)];
%% conbining into a big matrix
List=[List_0;List_1];
% clearvars List_0 List_1
%% sorting according to duration
duration=List(:,2)-List(:,1)+1;
[duration, order] = sort(duration);
List=List(order,:);
List_short=List(duration<state_dur,:);
List_short(:,4)=duration(duration<state_dur);
List_short(:,5:7)=zeros(size(List_short,1),3);
for n=1:size(List_short,1)
%% store the duration of the state before the n-th state
before=List_short(n,1)-1;
if before~=0
ind_before=(List(:,2)==before);
List_short(n,5)=duration(ind_before);
end
%% store the duration of the state after the n-th state
after=List_short(n,2)+1;
if after~=N+1
ind_after=(List(:,1)==after);
List_short(n,6)=duration(ind_after);
end
end
List_short(:,7)=List_short(:,5)+List_short(:,6);
if numel(List_short)>0
if stage==1
%% flipping states where each neighbor is at least as long as state_dur
List_flip=List_short(List_short(:,5)>=state_dur & List_short(:,6)>=state_dur,:);
elseif stage==2
%% flipping states where sum of neighbors duration is at least as long as state_dur
List_flip=List_short(List_short(:,7)>=state_dur,:);
end
List_flip=sortrows(List_flip,7,'descend');
if numel(List_flip)>0
for n=1:size(List_flip,1)
new_state_list(1,List_flip(n,1):List_flip(n,2))=1-new_state_list(1,List_flip(n,1):List_flip(n,2));
end
else
stop=1;
end
else
stop=1;
end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if size(List_short,1)>0
%     stage=3;
%     iter2=0;
%     while size(List_short,1)>0
%         iter2=iter2+1;
%         List_flip=sortrows(List_short,7,'descend');
%         new_state_list(1,List_flip(1,1):List_flip(1,2))=1-new_state_list(1,List_flip(1,1):List_flip(1,2));
%         val=new_state_list(1,List_flip(1,1));
%         List=List(~(List(:,1)==List_flip(1,1)& List(:,2)==List_flip(1,2)),:); % supress small portion
%         %% find begining of new larger state
%         before=List_flip(1,1)-1;
%         if before~=0
%             beg_state=List(List(:,2)==before,1);
%         else
%             beg_state=1;
%         end
%         %% find ending of new larger state
%         after=List_flip(1,2)+1;
%         if after~=N+1
%             end_state=List(List(:,1)==after,2);
%         else
%             end_state=N;
%         end
%         new_state=[beg_state,end_state,val];
%         List=List(~(List(:,2)==before | List(:,1)==after),: );
%         List=[List;new_state];
%         
%         %% sorting according to duration
%         duration=List(:,2)-List(:,1)+1;
%         [duration, order] = sort(duration);
%         List=List(order,:);
%         List_short=List(duration<state_dur,:);
%         List_short(:,4)=duration(duration<state_dur);
%         List_short(:,5:7)=zeros(size(List_short,1),3);
%         for n=1:size(List_short,1)
%             %% store the duration of the state before the n-th state
%             before=List_short(n,1)-1;
%             if before~=0
%                 ind_before=(List(:,2)==before);
%                 List_short(n,5)=duration(ind_before);
%             end
%             %% store the duration of the state after the n-th state
%             after=List_short(n,2)+1;
%             if after~=N+1
%                 ind_after=(List(:,1)==after);
%                 List_short(n,6)=duration(ind_after);
%             end
%         end
%         List_short(:,7)=List_short(:,5)+List_short(:,6);
%     end
% end   
end

