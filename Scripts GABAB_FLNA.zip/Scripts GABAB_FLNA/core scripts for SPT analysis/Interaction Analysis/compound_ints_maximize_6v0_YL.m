% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [compound_ints_durations, comp_ints_starts, comp_ints_ends] = compound_ints_maximize_6v0_YL(filenames,shiftXX,shiftYY, shiftTT, gap_wind,global_folders)

%description of int_families strcuture arrray tha contain most relevant
%information
%int_families.
%       .ints (the indexes of interactions in a family)
%       .int_linking_matrix (the linking matrix, where columns are the reference interactions, rows are the possible forward linking interractions, ones indicate a possible interaction)
%
%       .int_linking_matrix_mask_init (the single biunivocal initialized interaction matrix. The starting point for the optimization)
%       .int_linking_matrix_mask_current (the cuurent and best so far)
%       .int_linking_matrix_mask_test (the new test matrix after the perturb
%
%       .linked_ints_init
%       .nonlinked_ints_init
%       .linked_int_durations_init - .linked_int_durations_init
%       .nonlinked_int_durations_init - .nonlinked_int_durations_init
%       .linked_int_durationsAvg_init - .linked_int_durationsAvg_init
%
%       .linked_ints_current
%       .nonlinked_ints_current
%       .linked_int_durations_current - .linked_int_durations_current
%       ..nonlinked_int_durations_current - .nonlinked_int_durations_current

%       .linked_int_durationsAvg_cuurent - .linked_int_durationsAvg_current
%
%       .linked_ints_test
%       .nonlinked_ints_test
%       .linked_int_durations_test - .linked_int_durations_test
%       .nonlinked_int_durations_test - .nonlinked_int_durations_test
%       .linked_int_durationsAvg_test - .linked_int_durationsAvg_test
%
%
%       .track(iter).linked_int_durations
%       .track(iter).nonlinked_int_durations
%       .linked_int_durationsAvg_track

iter_max=2000;

Ch1_filename=char(filenames(1));
Ch2_filename=char(filenames(2));

%%%%%%%%%%%%%%
%search_radius=3;

%gap_wind=6; %time window in frames for joining two interactions (the start of the next int should be within the end of the previous +/- gap_wind)

%%%%%%
%step 0
%loading the intmatrix

filenameload=[Ch1_filename Ch2_filename '_intmatrix_' num2str(shiftXX) 'pShiftX-' num2str(shiftYY) 'pShiftY-' num2str(shiftTT) 'fShiftT' ];
load([global_folders.rawfolder, filesep,filenameload]);

%% %%%%%%%%%%%%%%%%%%%%%%
%STEP1 - generate the int_linking_matrix starting from the int_matrix (the
%previous interaction matrix). Each column correspond to an interaction and
%each row to an interaction that could link with it. The diagonal must
%contain zeros!

int_num=size(int_matrix,1); %the number of interactions

int_families=[]; %structure array int_families.int, contains all the interactions belonging to the same family of interaction, i.e. all the interactions that could be linked with each other, later used for maximization!!!!!!!

%initialize the int_linking_matrix
int_linking_matrix=zeros(int_num,int_num);
int_linking_matrix_durations=zeros(int_num,int_num);

%% filling the int_linking_matrix with ones for all possible linking interactions

[int_linking_matrix,int_linking_matrix_durations,int_families] = int_linking_v1(int_matrix,gap_wind);

%% sort and keep only unique int_families.ints
int_families_num=numel(int_families);

for i=1:int_families_num
int_families(i).ints=sort(unique(int_families(i).ints));
end

%% set the diagonals to zeros!!!! (one interaction cannot link to itself!!!)
int_linking_matrix=int_linking_matrix-diag(int_linking_matrix);
int_linking_matrix_durations=int_linking_matrix_durations-diag(int_linking_matrix_durations);

%% %%%%%%%%%%%%%
%generate a initialization duration matrix in which one level linking
%produces maximal linked durations!!!!! - the starting point for the
%permutations1!!!!!

int_linking_matrix_durations_temp=int_linking_matrix_durations;
int_linking_matrix_durations_init(1:int_num,1:int_num)=0;
int_linking_matrix_mask_init(1:int_num,1:int_num)=0;


[row,col]=find(int_linking_matrix_durations_temp>0);
list_temp=int_linking_matrix_durations_temp(sub2ind(size(int_linking_matrix_durations_temp),row,col));
list_dur=[row,col,list_temp];
list_dur=sortrows(list_dur,3,'descend');

number_int=size(list_dur,1);
while number_int>0
int_linking_matrix_mask_init(list_dur(1,1),list_dur(1,2))=1; %building the init mask matrix!
int_linking_matrix_durations_init(list_dur(1,1),list_dur(1,2))=list_dur(1,3); %building the init duration

A=list_dur(:,1)==list_dur(1,1) | list_dur(:,2)==list_dur(1,2);
number_int=number_int-sum(A);
list_dur(A,:)=[];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %STEP2 %pick up only a family of interactions and for eack of them find the best
% %linking matrix
%
% %go through all the int families
%
%disp(['interaction duration optimisation'])

%tic

for ifam=1:int_families_num
%ifam

%int_families(ifam).int_total_lnked_duration_track=[];
iter=1;

%generate an int_linking_matrix just for the ints in the family
ints_in_family=int_families(ifam).ints;
ints_in_family_num=numel(ints_in_family);
int_families(ifam).int_linking_matrix=int_linking_matrix(ints_in_family,ints_in_family);

int_families(ifam).int_linking_matrix_mask_init=int_linking_matrix_mask_init(ints_in_family,ints_in_family); %the single biunivocal linking matrix for which the durations of
%the linked ints are maximal, this is the starting matrix

%calculate the all linked durations for the starting matrix

[int_families(ifam).linked_ints_init int_families(ifam).linked_int_durations_init int_families(ifam).nonlinked_ints_init int_families(ifam).nonlinked_int_durations_init]=linkedIntDurations3_YL(int_families(ifam).int_linking_matrix_mask_init,ints_in_family,int_matrix);
int_families(ifam).track(iter).linked_int_durations =int_families(ifam).linked_int_durations_init; %to keep track of the evolution of the optimizaation
int_families(ifam).track(iter).nonlinked_int_durations=int_families(ifam).nonlinked_int_durations_init;

%calculate the average lenght of the linnked interactions %Willl be
%used for maximization!!!!!!!!!!!!!!!!!
int_families(ifam).linked_int_durationsAvg_init=sum(int_families(ifam).linked_int_durations_init)/numel(int_families(ifam).linked_int_durations_init);
int_families(ifam).compound_int_num_init=numel(int_families(ifam).nonlinked_ints_init)+numel(int_families(ifam).linked_ints_init);


int_families(ifam).linked_int_durationsAvg_track=int_families(ifam).linked_int_durationsAvg_init;

int_families(ifam).nonlinked_int_num_track=numel(int_families(ifam).nonlinked_ints_init);
int_families(ifam).compound_int_num_track=int_families(ifam).compound_int_num_init;


%%%%%%%%
int_families(ifam).int_linking_matrix_mask_current=int_families(ifam).int_linking_matrix_mask_init; %the currently selected biunivocal interacionn matrix!

int_families(ifam).linked_ints_current=int_families(ifam).linked_ints_init;
int_families(ifam).linked_int_durations_current=int_families(ifam).linked_int_durations_init;
int_families(ifam).nonlinked_ints_current=int_families(ifam).nonlinked_ints_init;
int_families(ifam).nonlinked_int_durations_current=int_families(ifam).nonlinked_int_durations_init;

int_families(ifam).linked_int_durationsAvg_current=int_families(ifam).linked_int_durationsAvg_init;
int_families(ifam).compound_int_num_current=int_families(ifam).compound_int_num_init;


if numel(int_families(ifam).ints)>1 %i.e. there are atl least two interactions ina family

while iter<iter_max
%randomly perturb the starting matrix (->test matrix)
[int_families(ifam).int_linking_matrix_mask_test] = matrixPerm_YL(int_families(ifam).int_linking_matrix_mask_current,int_families(ifam).int_linking_matrix,1);

%recalculate the all linked durations for the perturbed (test) matrix

[int_families(ifam).linked_ints_test int_families(ifam).linked_int_durations_test int_families(ifam).nonlinked_ints_test int_families(ifam).nonlinked_int_durations_test]=linkedIntDurations3_YL(int_families(ifam).int_linking_matrix_mask_test,ints_in_family,int_matrix);

int_families(ifam).linked_int_durationsAvg_test=sum(int_families(ifam).linked_int_durations_test)/numel(int_families(ifam).linked_int_durations_test);

int_families(ifam).compound_int_num_test=numel(int_families(ifam).nonlinked_ints_test)+numel(int_families(ifam).linked_ints_test);


%if the perturbed matrix less non linked interactions, keep it and
%repeat until the solution converges or the min is reached

%if int_families(ifam).linked_int_durationsAvg_test>int_families(ifam).linked_int_durationsAvg_current
%if numel(int_families(ifam).nonlinked_ints_test)<numel(int_families(ifam).nonlinked_ints_current)
if int_families(ifam).compound_int_num_test<=int_families(ifam).compound_int_num_current %chaned in test!!!!!!!!!

int_families(ifam).int_linking_matrix_mask_current=int_families(ifam).int_linking_matrix_mask_test; %the currently selected biunivocal interacionn matrix!

int_families(ifam).linked_ints_current=int_families(ifam).linked_ints_test;
int_families(ifam).linked_int_durations_current=int_families(ifam).linked_int_durations_test;
int_families(ifam).nonlinked_ints_current=int_families(ifam).nonlinked_ints_test;
int_families(ifam).nonlinked_int_durations_current=int_families(ifam).nonlinked_int_durations_test;
int_families(ifam).linked_int_durationsAvg_current=int_families(ifam).linked_int_durationsAvg_test;

int_families(ifam).compound_int_num_current=int_families(ifam).compound_int_num_test;


end
int_families(ifam).track(iter).linked_int_durations =int_families(ifam).linked_int_durations_test; %to keep track of the evolution of the optimizaation
int_families(ifam).track(iter).nonlinked_int_durations=int_families(ifam).nonlinked_int_durations_test;

int_families(ifam).linked_int_durationsAvg_track=[int_families(ifam).linked_int_durationsAvg_track int_families(ifam).linked_int_durationsAvg_test];

int_families(ifam).nonlinked_int_num_track=[int_families(ifam).nonlinked_int_num_track numel(int_families(ifam).nonlinked_ints_test)];
int_families(ifam).compound_int_num_track=[int_families(ifam).compound_int_num_track int_families(ifam).compound_int_num_test];

iter=iter+1;

end

end

end
%toc
%%%%%%%%%%%%%
%retrieving the optimized data and store them in compound_ints and
%compound_ints_durations - the real output of the routine!!!!!!!!
w=1;


%compound_ints=struct('ints', {});
compound_ints_all=[];

for ifam=1:int_families_num
for l=1:numel(int_families(ifam).linked_ints_current)
if ~isempty(int_families(ifam).linked_ints_current(l).ints)
compound_ints(w).ints=int_families(ifam).linked_ints_current(l).ints;

%compound_ints_durations(w)=int_families(ifam).linked_int_durations_current(l);

compound_ints_all=[compound_ints_all compound_ints(w).ints];
w=w+1;
end
end
end

for ifam=1:int_families_num
for l=1:numel(int_families(ifam).nonlinked_ints_current)
if ~isempty(int_families(ifam).nonlinked_ints_current(l))
compound_ints(w).ints=int_families(ifam).nonlinked_ints_current(l);
%compound_ints_durations(w)=int_families(ifam).nonlinked_int_durations_current(l);

compound_ints_all=[compound_ints_all compound_ints(w).ints];
w=w+1;
end
end
end


%%%%%%%%%%%%%%

%constructing a OBJ3 matrix, containg all the coordinates of the
%linked interactions. The OBJ family corresponds to the index of the
%compound interaction in compound_ints
%
%for plotting it will be sufficient to plot each interaction family with a
%different color


%go through all the compound ints and generate a new OBJ3


%preallocate OBJ3.trjRB
frame_num=size(Ch(1).OBJ.trjRB,2);

for c=1:2
Ch(c).OBJ3.trjRB(1:numel(compound_ints),1:frame_num)=NaN;
Ch(c).OBJ3.xR(1:numel(compound_ints),1:frame_num)=NaN;
Ch(c).OBJ3.yR(1:numel(compound_ints),1:frame_num)=NaN;
Ch(c).OBJ3.compound_int_start(1:numel(compound_ints))=frame_num;
Ch(c).OBJ3.compound_int_end(1:numel(compound_ints))=1;
end

%filling the OBJ3 matrix for each channel
for c=1:2

Ch(c).OBJ3.compound_ints=compound_ints;

for n=1:numel(compound_ints)

for i=1:numel(compound_ints(n).ints)

current_int=compound_ints(n).ints(i);
current_int_start=int_matrix(current_int,1);
current_int_end=int_matrix(current_int,2);
current_obj(c)=int_matrix(current_int,4*c);

if ~isnan(current_obj(c))

Ch(c).OBJ3.trjRB(n,current_int_start:current_int_end)=Ch(c).OBJ.trjRB(current_obj(c),current_int_start:current_int_end);
Ch(c).OBJ3.xR(n,current_int_start:current_int_end)=Ch(c).OBJ.xR(current_obj(c),current_int_start:current_int_end);
Ch(c).OBJ3.yR(n,current_int_start:current_int_end)=Ch(c).OBJ.yR(current_obj(c),current_int_start:current_int_end);

if current_int_start<=Ch(c).OBJ3.compound_int_start(n)
Ch(c).OBJ3.compound_int_start(n)=current_int_start;
end

if current_int_end>=Ch(c).OBJ3.compound_int_end(n)
Ch(c).OBJ3.compound_int_end(n)=current_int_end;
end

end

end

if Ch(c).OBJ3.compound_int_start(n)>Ch(c).OBJ3.compound_int_end(n)
Ch(c).OBJ3.compound_int_start(n)=NaN;
Ch(c).OBJ3.compound_int_end(n)=NaN;
end


end
end

comp_ints_starts=Ch(1).OBJ3.compound_int_start;
comp_ints_ends=Ch(1).OBJ3.compound_int_end;

compound_ints_durations=comp_ints_ends-comp_ints_starts+1; %fixed in 3v0!!!!


%save the int_matrix file!!!!!!!!!

shiftX=shiftXX;
shiftY=shiftYY;
shiftT=shiftTT;

%save(filenameload, 'Ch', 'int_matrix', 'lifetimes', 'shiftX', 'shiftY', 'shiftT', 'shift_distance', 'gap_wind','-v7.3');

save([global_folders.rawfolder, filesep,filenameload], 'Ch', 'int_matrix', 'shiftX', 'shiftY', 'shiftT', 'shift_distance', 'gap_wind','-v7.3');


end
