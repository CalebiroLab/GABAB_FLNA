% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
%ints Starshow v16. This routine plots x-y trajectories in OBJ structure. It
% requires an open OBJ file. parameters are:
% FileName: the root of the file name. Used for loading the TIFF sequence
% and for saving the results of Starshow as an .avi file.
% frameStart: first frame to visualize
% frameEnd: last frame to visualize
% OBJ: the OBJ structure.
% list: the list of compound objects (= original index from uTrack now stored in OBJ.family)
% to be visualized, e.g. [1,10,22] or 1:1000. If empty ([]) all objects are displayed.
% showMovie: if 1 traces are overlaid on the TIFF sequence, if 0 traces are
% plotted on a white background.
% regMatrix=file containing registration matrix, used to align channels
% 3v1: can load multiple movies with different registration matrices. It
% searches for particles in two channels that fall closer than searchRadius
% (nm).
% When two particles fall within searchRadius, objects are given a different class (i.e. 8) and an event is  saved in
% OBJ.intraChevents, as follows:
% column 1: frame at which interaction starts
% column 2: frame at which interaction ends
% column 3: channel number of first obj
% column 4: object number (in first channel)
% column 5: flag for true start (1, obj exist also at frame before
% interaction begins, 0 new appearance)
% column 6: flag for true end (1, obj exist also at frame after
% interaction ends, 0 object disappears)
% column 7: channel number of second obj
% column 8: object number (in second channel)
% column 9: flag for true start
% column 10: flag for true end

%from version 4v0: added newinput parameter shift=x, which is used for
%shifting 2nd channel of x pixels. Added routine to exclude objects (i.e.
%class=0) close to the border of the mask. This is performed by erodin the
%mask of a factor="erosion".

%From 4v1: accepts shifts in two directions (shiftX and shiftY)

% 4v6: it has a flag for using OBJ2 (trajetories reshaped to remove merhges
% and splits) instead of OBJ.

%4v8: shows interacting objs between two channels

%filenames={'aa', 'bb', 'cc'}

%4v9: for interaction analysis considers only objects in class=1, i.e.
%objects outside the mask (class=0) as well as objects that are short
%lived (class=2).

%4v10: joins interactions also if there is overlap between the end of the
%first and beginning of the second, provided there is no gap (t5o avoid
%problem with hiher search radius).

%7v0, based on 4v10!!!! (not on 5v0 or 6v0). Added time shift (shiftT)!


function [Ch, int_matrix]=gap_close_interaction_matrix_v1_YL(FileNames, regMatrix, shiftX, shiftY, shiftT, frameStart,frameEnd,list1, list2, list3, list4,class,searchRadius, showTracks,showMovie, global_folders)

%global rawfolder

use_OBJ2=1; %if =1 uses OBJ2, else OBJ.
exclude_dark_obj=0; %flag for setting OBJ.xR and OBJ.yR to NaN, if OBJ.trjRB=NaN (i.e. the particle dissappeared).
gap_fill=1; % flag for filling the gaps in OBJ(2).xR and yR

exclude_duplicate_int=0; %flag for excluding shorter duplicate interactions. It assumes that a particle in one channel at a given time can interac only with one particle in the second channel. If one particle interacts simulatenously with two particles (i.e. due to true + random colocalization), the shorter interaction is removed.

%shift=1; %for testing, translates 2nd channel of x pixels!


%%%%%%%%%%%%%%
%min and max intensity value in movies, used for visualization. %if both emty,
%it will use min and max values in the current movie. Ifonly int_max empty,
%it will use background value and max value = background + int_max

int_min=[]; %0.0293 %1900/65535;

int_max=[]; % 0.0579 %2000/65535;

linespecs1={'-r' '-g' '-b' '-m'};  %linespecs1={'-b' '-g' '-r' '-m'};

linespecs2={'or' 'og' 'ob' 'om'};  %linespecs2={'ob' 'og' 'or' 'om'};

%linespecs3={'--b' '--y' '--r' '--m'};
linespecs3={'-b' '-b' '-b' '-b'}; %linespecs3={'-r' '-r' '-r' '-r'};

linespecs4={'om' 'ow' 'ob' 'om'};  %linespecs2={'ob' 'og' 'or' 'om'};


RGBcolor =[1 2 3]; %RGBcolor =[3 2 1]; %determines the color used to visualise the different channels in RBG movie

erosion = 20; %factor used for eroding the mask. Object falling outside the eroded mask are classified as 0. added in 4v0. %default=20;

test=0; %flag for test, if=0 uses same matrix (Ch=1) for calculating interactions

%%%%%%%%%%%%%%%%%
%loading OBJ files

if ~isempty([global_folders.rawfolder, filesep,FileNames])

fileNameIndexes=find(strcmp(FileNames,'')==0);

for channel=fileNameIndexes
temp=load ([global_folders.rawfolder, filesep, char(FileNames(channel)), '_gui2_steps.mat']);

if use_OBJ2==1
Ch(channel).OBJ=temp.OBJ2;
else
Ch(channel).OBJ=temp.OBJ;
end
%Ch(i).IFO=temp.IFO;
%now filling the gaps in x and y coordinates
if gap_fill==1
nan_intensities=find(isnan(Ch(channel).OBJ.trjRB)); %set coordinates to NaN if intensity is NaN!!!!
Ch(channel).OBJ.xR(nan_intensities)=NaN;
Ch(channel).OBJ.yR(nan_intensities)=NaN;

M=size(Ch(channel).OBJ.xR,1);
list_exist=~isnan(Ch(channel).OBJ.xR);

for m=1:M
pos_beginning=find(list_exist(m,:),1);
if ~isempty(pos_beginning)
[ List_min_max ] = Make_list_min_max_index_equal_YL( list_exist(m,pos_beginning:end)',1 );
if size(List_min_max,1)>1
for n_gap=1:size(List_min_max,1)-1
gap_fstart=List_min_max(n_gap,2)+1+pos_beginning-1;
gap_fend=List_min_max(n_gap+1,1)-1+pos_beginning-1;
Ch(channel).OBJ.xR(m,gap_fstart-1:gap_fend+1)=linspace(Ch(channel).OBJ.xR(m,gap_fstart-1),Ch(channel).OBJ.xR(m,gap_fend+1),gap_fend-gap_fstart+3);
Ch(channel).OBJ.yR(m,gap_fstart-1:gap_fend+1)=linspace(Ch(channel).OBJ.yR(m,gap_fstart-1),Ch(channel).OBJ.yR(m,gap_fend+1),gap_fend-gap_fstart+3);
end
end
end
end

%             framenum=size(Ch(channel).OBJ.xR,2);
%             objnum=size(Ch(channel).OBJ.xR,1);
%
%             for ob=1:objnum
%                 obj_fstart=find(~isnan(Ch(channel).OBJ.xR(ob,:)),1); %do not connsider NaNs before the beginning of an object
%                 f=obj_fstart;
%
%                 while f<framenum
%                     if isnan(Ch(channel).OBJ.xR(ob,f))% a gap start is found
%                         gap_fstart=f;
%                         f2=f+1;
%                         gap_end_fnd=0;
%                         while gap_end_fnd==0 && f2<=framenum
%                             if ~isnan(Ch(channel).OBJ.xR(ob,f2)) % a gap end is found
%                                 gap_fend=f2-1;
%                                 Ch(channel).OBJ.xR(ob,gap_fstart-1:gap_fend+1)=linspace(Ch(channel).OBJ.xR(ob,gap_fstart-1),Ch(channel).OBJ.xR(ob,gap_fend+1),gap_fend-gap_fstart+3);
%                                 Ch(channel).OBJ.yR(ob,gap_fstart-1:gap_fend+1)=linspace(Ch(channel).OBJ.yR(ob,gap_fstart-1),Ch(channel).OBJ.yR(ob,gap_fend+1),gap_fend-gap_fstart+3);
%                                 gap_end_fnd=1;
%                                 f=f2+1;
%                             end
%                             f2=f2+1;
%                         end
%                     end
%                     f=f+1;
%                 end
%             end
%
end

end

end



%movieRGB(:,:,1:max(fileNameIndexes),1:frameEnd)=0;

%loading the movies

if showMovie==1

if ~isempty([global_folders.rawfolder, filesep,FileNames])

for channel=fileNameIndexes

FileNameLoad = [global_folders.rawfolder, filesep,char(FileNames(channel)), '.tif'];
display('loading....');    tic ;

for frame=frameStart:frameEnd
[Ch(channel).movie16b(:,:,1,frame)] = imread(FileNameLoad,frame);

%movieRGB(:,:,i,frame)=Ch(i).movie16b(:,:,1,frame);



end

%adjusting for visualization


if isempty(int_min) && isempty(int_max)
min_max=stretchlim(Ch(channel).movie16b(:,:,1,frameStart));
end

if isempty(int_min) && ~isempty(int_max)
min_max=stretchlim(Ch(channel).movie16b(:,:,1,frameStart));
min_max(2)=min_max(1)+int_max;
end


if ~isempty(int_min) && ~isempty(int_max)
min_max=[int_min int_max];
end

for f = frameStart:frameEnd


Ch(channel).movie16bAdj(:,:,1,f)=imadjust(Ch(channel).movie16b(:,:,1,f),min_max);


%movie16bAdj(:,:,i,f)=imadjust(Ch(i).movie16b(:,:,1,f),min_max);

end


end


framesize=size(Ch(channel).movie16bAdj(:,:,1,f));


end


else


framesize=[256 256]; %temporary!!!!!!!



end





%loading registration matrix
load ([global_folders.rawfolder, filesep,regMatrix])

%% changing coordinates
for c=fileNameIndexes     %fileNameIndexes(2:end)
if c>=2
[Ch(c).OBJ.xR, Ch(c).OBJ.yR] = transformPointsInverse(t_piecewise_linear{c}, Ch(c).OBJ.xR, Ch(c).OBJ.yR); %transform xy_n to match coordinates into xy_1!!!!!!!!!!!!!!!!

end
end

%%
%now shifting the Ch2!!! added in 7v0!!!!!!!!!!!!

Ch(2).OBJ.xR(:,1:end-shiftT)=Ch(2).OBJ.xR(:,shiftT+1:end);
Ch(2).OBJ.xR(:,end-shiftT+1:end)=NaN;
Ch(2).OBJ.yR(:,1:end-shiftT)=Ch(2).OBJ.yR(:,shiftT+1:end);
Ch(2).OBJ.yR(:,end-shiftT+1:end)=NaN;

Ch(2).OBJ.mxR(:,1:end-shiftT)=Ch(2).OBJ.mxR(:,shiftT+1:end);
Ch(2).OBJ.mxR(:,end-shiftT+1:end)=NaN;
Ch(2).OBJ.myR(:,1:end-shiftT)=Ch(2).OBJ.myR(:,shiftT+1:end);
Ch(2).OBJ.myR(:,end-shiftT+1:end)=NaN;

Ch(2).OBJ.trjRB(:,1:end-shiftT)=Ch(2).OBJ.trjRB(:,shiftT+1:end);
Ch(2).OBJ.trjRB(:,end-shiftT+1:end)=NaN;
Ch(2).OBJ.trjRB_smo(:,1:end-shiftT)=Ch(2).OBJ.trjRB_smo(:,shiftT+1:end);
Ch(2).OBJ.trjRB_smo(:,end-shiftT+1:end)=NaN;
Ch(2).OBJ.strjRB(:,1:end-shiftT)=Ch(2).OBJ.strjRB(:,shiftT+1:end);
Ch(2).OBJ.strjRB(:,end-shiftT+1:end)=NaN;
Ch(2).OBJ.n_strjRB(:,1:end-shiftT)=Ch(2).OBJ.n_strjRB(:,shiftT+1:end);
Ch(2).OBJ.n_strjRB(:,end-shiftT+1:end)=NaN;

Ch(2).OBJ.xR=Ch(2).OBJ.xR+shiftX;
Ch(2).OBJ.yR=Ch(2).OBJ.yR+shiftY;
Ch(2).OBJ.mxR=Ch(2).OBJ.mxR+shiftX;
Ch(2).OBJ.myR=Ch(2).OBJ.myR+shiftY;


Ch(2).OBJ.events(:,1:4)=Ch(2).OBJ.events(:,1:4)-shiftT;
Ch(2).OBJ.events(Ch(2).OBJ.events<=0)=1;


%%%%%%%%%%%
%added in 4v0 to exclude objects close to the border of the mask
%v7v0, limit this only to Ch1 (the non-shifted one)!


%load mask

%for i=fileNameIndexes

for channel=1

Ch(channel).mask=imread ([global_folders.rawfolder, filesep,char(FileNames(channel)) '_msk.tif']);

%% erode mask!
se = strel('disk',erosion);
Ch(channel).mask2 = imerode(Ch(channel).mask,se);


%exclude objects (i.e. set class=0) if they fall outside the eroded mask
%7v0, it is sufficeint to perform this on the non-shifted channel, i.e.
%channel 1!

for u = 1:size (Ch(channel).OBJ.trjRB,1);
startFr=Ch(channel).OBJ.events(u,3);
if ~isnan(startFr)
startX=Ch(channel).OBJ.mxR(u,startFr);
startY=Ch(channel).OBJ.myR(u,startFr);

if Ch(channel).mask2(startY,startX)==0
Ch(channel).OBJ.class(u)=0;

else
%plot (startX, startY,'o');
end
end

end

%hold off

end


%%%%%%%%



%generate merged RGB movie

%frameRGB(1:framesize(1),1:framesize(2),1:3)=0;

%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%find objects in two challes that fall closer then searchRadius (for now
%just between ch 1 and 2)

%frameStart=1;
%frameEnd=2;
%searchRadius=2;

eventn=0;
found=0;

for d=fileNameIndexes
%exclude1=find(isnan(Ch(d).OBJ.trjRB)); %temporary to set ppp.xR and ppp.yR if ppp.trjRB=NaN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%Ch(d).OBJ.xR(exclude1)=NaN;
%Ch(d).OBJ.yR(exclude1)=NaN;
for obj2=1:size(Ch(d).OBJ.xR,1) %temporary to set ppp.xR and ppp.yR if ppp.trjRB=NaN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
if Ch(d).OBJ.events(obj2,3)>1
Ch(d).OBJ.xR(obj2,1:Ch(d).OBJ.events(obj2,3)-1)=NaN;
Ch(d).OBJ.yR(obj2,1:Ch(d).OBJ.events(obj2,3)-1)=NaN;
end
if Ch(d).OBJ.events(obj2,4)<frameEnd
Ch(d).OBJ.xR(obj2,Ch(d).OBJ.events(obj2,4)+1:frameEnd)=NaN;
Ch(d).OBJ.yR(obj2,Ch(d).OBJ.events(obj2,4)+1:frameEnd)=NaN;
end
end
end
Ch(1).OBJ.intraChevents (1:10) =NaN;
%% interaction matrix
for t=frameStart:frameEnd
%% distance calculation
Idx_nearest_neighbors = rangesearch([Ch(2).OBJ.xR(:,t),Ch(2).OBJ.yR(:,t)],[Ch(1).OBJ.xR(:,t),Ch(1).OBJ.yR(:,t)],searchRadius);   
for channel=1:size(Ch(1).OBJ.xR,1)
nearpointIndexes=Idx_nearest_neighbors{channel}; %objs in ch2 that at frame t intract with obj(i) in ch 1
%%
if isempty(nearpointIndexes)==0
for w=1:numel(nearpointIndexes)
found=0;
intobj_1=channel;
intobj_2=nearpointIndexes(w);
%% modify list of event to update interaction last time
%                 for z=1:eventn
%                     if Ch(1).OBJ.intraChevents(z,4)==intobj_1 && Ch(1).OBJ.intraChevents(z,8)==intobj_2 && (Ch(1).OBJ.intraChevents(z,2)==t-1)
%                         Ch(1).OBJ.intraChevents(z,2)=t; %prologues interaction of one frame if interaction already existed at frame=t-1
%                         found=1;
%                     end
%                 end
test_exist=Ch(1).OBJ.intraChevents(:,4)==intobj_1 & Ch(1).OBJ.intraChevents(:,8)==intobj_2 & Ch(1).OBJ.intraChevents(:,2)==t-1;
if any(test_exist)==1 % if at least one element of text_exist is nonzero
Ch(1).OBJ.intraChevents(test_exist,2)=t;% interaction time is updated
else

%% otherwise, i.e. new interaction:
if found==0 && any([1 2 8]==Ch(1).OBJ.class(intobj_1)) && any([1 2 8]==Ch(2).OBJ.class(intobj_2)) %exclude objects falling outside mask (i.e. class=0)
eventn=eventn+1;

Ch(1).OBJ.intraChevents(eventn,1) = t;
Ch(1).OBJ.intraChevents(eventn,2) = t;
Ch(1).OBJ.intraChevents(eventn,3) = 1; %temporary for ch1
Ch(1).OBJ.intraChevents(eventn,4) = intobj_1;
Ch(1).OBJ.intraChevents(eventn,5) = Ch(1).OBJ.events(intobj_1,5); %flag for true start, data taken direcly from Ch.OB.events (number of parent object or NaN for true start)
Ch(1).OBJ.intraChevents(eventn,6) = Ch(1).OBJ.events(intobj_1,6); %flag for true end, data taken direcly from Ch.OB.events (number of child object or NaN for true end)
Ch(1).OBJ.intraChevents(eventn,7) = 2; %temporary for ch2
Ch(1).OBJ.intraChevents(eventn,8) = intobj_2;
Ch(1).OBJ.intraChevents(eventn,9) = Ch(2).OBJ.events(intobj_2,5); %flag for true start, data taken direcly from Ch.OB.events (number of parent object or NaN for true start)
Ch(1).OBJ.intraChevents(eventn,10) = Ch(2).OBJ.events(intobj_2,6); %flag for true end, data taken direcly from Ch.OB.events (number of child object or NaN for true end)

Ch(1).OBJ.class(intobj_1)=8; %assigns class 8 to interacting objects
Ch(2).OBJ.class(intobj_2)=8;

%found=0;
end
end

end



end



end


end

%% exlude duplicate interactions
%in case an object interacts simultaneously with two objects, it removes
%the shorter interaction (i.e. presumably a random colocalization)

if exclude_duplicate_int==1

%for objs in ch1
for channel=1:eventn
obj_ch1=Ch(1).OBJ.intraChevents(channel,4);
int_family=find(Ch(1).OBJ.intraChevents(:,4)==obj_ch1); %index to all interactions that involve obj_ch1
int_family=int_family';
if numel(int_family)>1 %as long as there is more than one interaction involving the same obj_ch1
for int1=int_family
for int2=int_family(int_family~=int1)
%check if interaction is contained in any other interaction (i.e.
%it start after and ends before another one
if Ch(1).OBJ.intraChevents(int1,1)>=Ch(1).OBJ.intraChevents(int2,1) && Ch(1).OBJ.intraChevents(int1,2)<=Ch(1).OBJ.intraChevents(int2,2)
%then remove the interaction
Ch(1).OBJ.intraChevents(int1,1:8)=NaN;
end
end
end
end
end

%now for objs in ch2
for channel=1:eventn
obj_ch2=Ch(1).OBJ.intraChevents(channel,8);
int_family=find(Ch(1).OBJ.intraChevents(:,4)==obj_ch2); %index to all interactions that involve obj_ch1
int_family=int_family';
if numel(int_family)>1 %as long as there is more than one interaction involving the same obj_ch1
for int1=int_family
for int2=int_family(int_family~=int1)
%check if interaction is contained in any other interaction (i.e.
%it start after and ends before another one
if Ch(1).OBJ.intraChevents(int1,1)>=Ch(1).OBJ.intraChevents(int2,1) && Ch(1).OBJ.intraChevents(int1,2)<=Ch(1).OBJ.intraChevents(int2,2)
%then remove the interaction
Ch(1).OBJ.intraChevents(int1,1:8)=NaN;
end
end
end
end
end
end

%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%
for channel=fileNameIndexes
if exclude_dark_obj==1
exclude=(isnan(Ch(channel).OBJ.trjRB)); %temporary to set ppp.xR and ppp.yR if ppp.trjRB=NaN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Ch(channel).OBJ.xR(exclude)=NaN;
Ch(channel).OBJ.yR(exclude)=NaN;
end
Ch(channel).OBJdisp.x=Ch(channel).OBJ.xR';
Ch(channel).OBJdisp.y=Ch(channel).OBJ.yR';
end

%%%%%%%%%%%%%%%%%%

%if showTracks==1
%generate matrix with merge and split events for plotting

Ch(1).list=list1;
Ch(2).list=list2;
Ch(3).list=list3;
Ch(4).list=list4;

for c=fileNameIndexes

Ch(c).objToShow=[];
%select only compund objects in list

if isempty(Ch(c).list)==1
Ch(c).objToShow=1:size(Ch(c).OBJ.xR,1);
else
for channel =1:numel(Ch(c).list)
objInCompTrk=find(Ch(c).OBJ.family==Ch(c).list(channel));
Ch(c).objToShow=[Ch(c).objToShow objInCompTrk'];
end
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% reorganizing split and merge data

for channel=fileNameIndexes
Ch(channel).splits.x1(1:size(Ch(channel).OBJ.xR,1),1:size(Ch(channel).OBJ.xR,2))=NaN;
Ch(channel).splits.y1(1:size(Ch(channel).OBJ.yR,1),1:size(Ch(channel).OBJ.yR,2))=NaN;
Ch(channel).splits.x2(1:size(Ch(channel).OBJ.xR,1),1:size(Ch(channel).OBJ.xR,2))=NaN;
Ch(channel).splits.y2(1:size(Ch(channel).OBJ.yR,1),1:size(Ch(channel).OBJ.yR,2))=NaN;

Ch(channel).merges.x1(1:size(Ch(channel).OBJ.xR,1),1:size(Ch(channel).OBJ.xR,2))=NaN;
Ch(channel).merges.y1(1:size(Ch(channel).OBJ.yR,1),1:size(Ch(channel).OBJ.yR,2))=NaN;
Ch(channel).merges.x2(1:size(Ch(channel).OBJ.xR,1),1:size(Ch(channel).OBJ.xR,2))=NaN;
Ch(channel).merges.y2(1:size(Ch(channel).OBJ.yR,1),1:size(Ch(channel).OBJ.yR,2))=NaN;  

for s=1:size(Ch(channel).OBJ.xR,1)
startObj=Ch(channel).OBJ.events(s,5); %finding splits

if (isnan(startObj)==0)
eventFrame=Ch(channel).OBJ.events(s,3);
endObj=s;

Ch(channel).splits.x1(s,eventFrame)=Ch(channel).OBJ.xR(startObj,eventFrame-1);
Ch(channel).splits.x2(s,eventFrame)=Ch(channel).OBJ.xR(endObj,eventFrame);
Ch(channel).splits.y1(s,eventFrame)=Ch(channel).OBJ.yR(startObj,eventFrame-1);
Ch(channel).splits.y2(s,eventFrame)=Ch(channel).OBJ.yR(endObj,eventFrame);
end
endObj=Ch(channel).OBJ.events(s,6);  %findings merges
if (isnan(endObj)==0)
eventFrame=Ch(channel).OBJ.events(s,4);
startObj=s;

Ch(channel).merges.x1(s,eventFrame)=Ch(channel).OBJ.xR(startObj,eventFrame-1);
Ch(channel).merges.x2(s,eventFrame)=Ch(channel).OBJ.xR(endObj,eventFrame);
Ch(channel).merges.y1(s,eventFrame)=Ch(channel).OBJ.yR(startObj,eventFrame-1);
Ch(channel).merges.y2(s,eventFrame)=Ch(channel).OBJ.yR(endObj,eventFrame);
end
end
end

for q=frameStart:frameEnd
%code to show only active tracks
for channel=fileNameIndexes
if isempty(class)==1
Ch(channel).activeOBJindex=find(Ch(channel).OBJ.events(Ch(channel).objToShow,1)<=q & Ch(channel).OBJ.events(Ch(channel).objToShow,2)>=q);%find all active objects at current frame belonging to defined class
else
Ch(channel).activeOBJindex=[];
for cl=1:numel(class)
Ch(channel).activeOBJindex=[Ch(channel).activeOBJindex ; find(Ch(channel).OBJ.events(Ch(channel).objToShow,1)<=q & Ch(channel).OBJ.events(Ch(channel).objToShow,2)>=q & Ch(channel).OBJ.class(Ch(channel).objToShow)'==class(cl))]; %find all active objects at current frame
end
end
Ch(channel).activeOBJ=Ch(channel).objToShow(Ch(channel).activeOBJindex);
end
end


%%%%%%%%%%%%%%%%
%calculate interaction matrices

%first the matrix based on individual interactions
int_matrix=Ch(1).OBJ.intraChevents;

%lifetime of all interactions, merging interactions that come from a
%previous one


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% save files
%cd (global_folders.rawfolder);
FileNameSave='';
for ff=fileNameIndexes
FileNameSave=[FileNameSave char(FileNames(ff))]; 
end
shift_distance=sqrt(shiftX^2+shiftY^2);
%cd(global_folders.rawfolder);
save([global_folders.rawfolder, filesep, FileNameSave '_intmatrix_' num2str(shiftX) 'pShiftX-' num2str(shiftY) 'pShiftY-' num2str(shiftT) 'fShiftT'], 'Ch', 'int_matrix', 'shiftX', 'shiftY', 'shiftT', 'shift_distance', '-v7.3');
end
