% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [int_linking_matrix,int_linking_matrix_durations,int_families] = int_linking_v1(int_matrix,gap_wind)
%from interaction matrix generates int_linking_matrix,int_linking_matrix_durations,int_families

%% computation of int_linking_matrix
int_linking_matrix=((int_matrix(:,4)==int_matrix(:,4)')|((int_matrix(:,8)==int_matrix(:,8)')))&((int_matrix(:,1)>= (int_matrix(:,2)-gap_wind+1)')&(int_matrix(:,1)<= (int_matrix(:,2)+gap_wind+1)')&(int_matrix(:,2)>int_matrix(:,2)'));

int_linking_matrix=int_linking_matrix-diag(diag(int_linking_matrix)); % remove diagonal terms
[int1,int2]=find(int_linking_matrix==1); % find connected interaction pairs

%% compute duration of combined pairs of interactions
int_linking_matrix_durations=zeros(size(int_linking_matrix));% init int_linking_duration
int_linking_matrix_durations(sub2ind(size(int_linking_matrix_durations),int1,int2))=(int_matrix(int1,2)-int_matrix(int1,1)+1)+(int_matrix(int2,2)-int_matrix(int2,1)+1);% int_linking_durations are duration of interaction 1 + duration of interaction int2

%% find interaction families (connected subgraphs) in the  int_linking_matrix (symetrised transition matrix with added diagonal terms)
idx_int_family = conncomp(graph(int_linking_matrix+int_linking_matrix'+eye(size(int_linking_matrix,1))));%find all disconencted components
list_fam_unique=unique(idx_int_family); % unique family number occurences

list_int_idx=1:numel(idx_int_family ); % all interaction IDs
int_families=[]; % init int_families
%% add interaction families
for n_fam=list_fam_unique
int_families(n_fam).ints=sort(list_int_idx(idx_int_family==n_fam));
end
end

