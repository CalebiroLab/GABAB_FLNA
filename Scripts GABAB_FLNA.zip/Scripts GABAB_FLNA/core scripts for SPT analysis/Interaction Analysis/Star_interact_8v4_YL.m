% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
%Star_interact_1v1. This routine loads multiple 2-colour movies (can be
%expanded to 4 colours), register them, shows movies/traces (option), find
%interacting particles and makes some statistics.

%2v1: routined transformed in function with files and reMatrix as inputs

%3v0: added shift!

% version 4v0: it calculates fraction of interacting particles with given
% shifts and search radius between particles tracked into two separate
% channels. It accepts shiftX and shift Y as vectors.

%version 4v3: uses OBJ2 (trajetories reshaped to remove merhges
% and splits) instead of OBJ.

%5v0: it now uses function based on test_maximize_new5 to build best
%compound interactions based on Monte Carlo approach. Is saves durations of
%compount interactions for each shift into the int_matrix2 file as
%compound_int_durations.

%7v0 now callling new routine for linking interactions (compound ints
%maximize 3v0)

%8v0 change transformation to be compatible with Matlab R2017!!!!

% (C) Davide Calebiro May 12 2014.
%%%%%%%%%%%%%%%%%%

function [shift, FileNameSave]=Star_interact_8v4_YL(files, searchRadius, regMatrix, shiftXi, shiftYi, shiftTi, frameStart,frameEnd, global_folders)

%general parameters
%close all;

% global rawfolder

class=[8]; %if class=8 shows only interacting objects

showTracks=0;
showMovie=0;

% searchRadius =150; %in nm %default=330? - it is part of the function now

pixelSize= 106.7; %in nm - has been corrected to the new value ZK 2019-08-30

gap_wind=3; %default=6!!!!!

searchRadius=searchRadius/pixelSize;

savefile=1;

%%%%%

n=1;


for shiftXX=shiftXi

for shiftYY=shiftYi

for shiftTT=shiftTi

%changed to be compatible with R2007!!!!!
%[Ch, int_matrix]=starshow_4D_7v0 (files, char(regMatrix), shiftXX, shiftYY, shiftTT, frameStart,frameEnd,[], [], [], [],class,searchRadius, showTracks,showMovie); %tegistartion of matrices and initial int matrix
%[Ch, int_matrix]=starshow_4D_9v0_ZK (files, char(regMatrix), shiftXX, shiftYY, shiftTT, frameStart,frameEnd,[], [], [], [],class,searchRadius, showTracks,showMovie, global_folders); %tegistartion of matrices and initial int matrix
% Yann changed to gap_close_interaction_matrix_v1_YL to make the interaction analysis faster
% 2020-11-27
% disp('Gap closing and creating interaction matrix')
%tic
[Ch, int_matrix]=gap_close_interaction_matrix_v1_YL(files, char(regMatrix), shiftXX, shiftYY, shiftTT, frameStart,frameEnd,[], [], [], [],class,searchRadius, showTracks,showMovie, global_folders); %tegistartion of matrices and initial int matrix
% toc
%shift(n).matrix=int_matrix;

%shift(n).lifetimes=lftimes;

shift(n).shiftX=shiftXX;

shift(n).shiftY=shiftYY;

shift(n).shiftT=shiftTT;

shift(n).distance=sqrt(shiftXX^2+shiftYY^2);


%shift(n).Ch=Ch;

%calls function that builds compound interactions (i.e. it tries to
%link interactions to remove gaps) based on Monte Carlo approach
% 2020-12-01 changed to 4v0 to improve speed
[shift(n).compound_ints_durations, shift(n).compound_ints_starts, shift(n).compound_ints_ends]=compound_ints_maximize_6v0_YL(files, shiftXX, shiftYY, shiftTT, gap_wind,global_folders); %the relevant data for the analysis of lifetime of interaction duration!!!!!

n=n+1;

end

end
end



%saving

frame_num=frameEnd-frameStart+1;


if savefile==1
if ~isempty(files)
fileNameIndexes=find(strcmp(files,'')==0);
end

FileNameSave='';

for ff=fileNameIndexes

FileNameSave=[FileNameSave char(files(ff))];

end

calmatrix = char(regMatrix);

%save([FileNameSave '_intmatrix2'], 'shift.lifetimes', 'shift.shiftX', 'shift.shiftY', 'shift.distance');
save ([global_folders.rawfolder, filesep, FileNameSave '_intmatrix2'], 'shift', 'calmatrix', 'frame_num', 'searchRadius', '-v7.3');

end


end

