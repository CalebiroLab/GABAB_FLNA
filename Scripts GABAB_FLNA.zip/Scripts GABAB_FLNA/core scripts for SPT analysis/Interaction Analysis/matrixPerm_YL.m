% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [matrix_out] = matrixPerm_YL(matrix_in_1,matrix_in_2,biunivocal)
%this routine replaces one value of matrix_in_1 with one random value taken
%from matix_in_2. If biunivocal==1, it reiterates until a set is found
%for which each raw and each column contain no more than one TRUE (i.e. each 
%link is either biunivocal or the int links to none).

found=0;
[row,col]=find(matrix_in_2>0);
n_row=size(row,1);
while found==0 && n_row>0

n=size(matrix_in_1,2); %the number of columns

pos=randi(n_row);
j=row(pos);
i=col(pos);


% ij_val=0;
% while ij_val==0 %finds pointers to a random cell containing a non-zero value
% i=randi(n);
% j=randi(n);
% ij_val=matrix_in_2(j,i);
% end


matrix_out=matrix_in_1;
matrix_out(:,i)=0;
matrix_out(j,:)=0;
matrix_out(j,i)=1;

if biunivocal==0
found=1;
else
if any(sum(matrix_out,1)>1)==0 && any(sum(matrix_out,2)>1)==0 %i.e. each link is either biunivocal or the int links to none
found=1;
else
row(pos)=[];
col(pos)=[];
n_row=n_row-1;
end
end

end

end

