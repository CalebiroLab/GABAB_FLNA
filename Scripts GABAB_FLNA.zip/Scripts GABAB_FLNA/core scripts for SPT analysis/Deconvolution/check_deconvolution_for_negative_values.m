% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
for i = 1:numel(data.file)
negative_values{i}=find(data.file(i).kfor_vs_time<0);
end
negative_values=negative_values';
