% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function [] = deconvolution_lucy_v37(filenames_data,filenames_control,save_path,show_plot, groupname_data, groupname_control, kloss_input, save_version, global_folders)
%global_folders_v2
% INPUT
% filenames_data = cell of dim 1xm, containing name of data to be
% deconvolved. Ex: {'TC634-C1TC634-C2'}
% filenames_control = cell of dim 1xm, containing name of dcontrol data for
% deconvolution. Ex: {'TC634-C1TC634-C2'}
% save_path = path of file wjere results are saved
% show_plot = must be 1 is the plot should be shown, doesn't plot in any
% case, default case: doesn't plot

% the random colocalization times are collected and binned 
% 
filenamesave=([groupname_data, ' with ', groupname_control, '_', save_version]);
%filenamesave=input('Filenamebase (e.g. b1AR_bArr2_nostim with CD86_bArr_nostim_negative removed): ','s');
%filenamesave=[groupname_data]; - Davide was using this

bin_size=4; %d=4; bin size in frame number used to bin colocalization durations
time_int=0.03; %time in sec
%kl=0; % this is for simulated data to get k_loss

kl=kloss_input;
%kl=0.4038; % this is for no stimulation group
%kl=0.4728; % this is for early stimulation group
%kl=0.4051; % this is for late stimulation group

%k loss in seconds-1 - we need to measure this (bleaching and loss of particles during tracking)

pixel_size=0.1067; %pixel size in mcm 

fr_show=150; %number of frames to be shown on graphs
interval_average_kon=20:200;% fames on which to average values for calculating kon (kfor)
Exclude_number_point=10; % minimum number of colocalization events within a bin


duration_max=Inf; %IMPORTANT for real data: do not touch!; %maximum duration allowd. ALl longer interactions are removed. Used to remov interactions that last for entire movie
% lucy_v37
exclude_frames=20/bin_size;

fitting_comps=1; %default is 2, it fits with constant plus exponential decay. If = 1, it fits only with decay (for b2 data!!!!)
deconv_lucy_iteration_number=7;

if nargin == 3
    show_plot=0;
end

%%load and append all durations apparent colocalizations between two channels from the tested data

signal_conv_d=[];
for f=1:numel(filenames_data)   
    load ([global_folders.rawfolder, filesep, char(filenames_data(f)), '_intmatrix2'])
    signal_conv_d=[signal_conv_d shift(1).compound_ints_durations]; 
end

signal_conv_d=signal_conv_d(signal_conv_d<duration_max);

signal_conv=hist(signal_conv_d,1:bin_size:max(signal_conv_d)); %the distribution of colocalizations of different time



%% loading int2matrix for the control
IRF_d=[];
for f=1:numel(filenames_control)   
    load ([global_folders.rawfolder, filesep, char(filenames_control(f)), '_intmatrix2'])
    IRF_d=[IRF_d shift(1).compound_ints_durations]; 
end

IRF_d=IRF_d(IRF_d<duration_max);

IRF=hist(IRF_d,1:bin_size:max(IRF_d)); %the IRF


%% adding zeros to make signal_conv at least as long as IRF.
signal=[];
if numel(IRF)<numel(signal_conv)
IRF(1,numel(IRF)+1:numel(signal_conv))=0; 
elseif numel(IRF)>numel(signal_conv)
   signal_conv(1,numel(signal_conv)+1:numel(IRF))=0;  
end
%% make the vectors of even size
if mod(numel(IRF),2)==1
    IRF=[IRF,0];
    signal_conv=[signal_conv,0];
end
%% set to zero points from the distribution with less than 'Exclude_number_point' events
signal_conv(signal_conv<=Exclude_number_point)=0;
IRF(IRF<=Exclude_number_point)=0;
%% Remove tail after the first zero in the interaction duration distribution
% idx=find(IRF==0);
% if numel(idx)>0
% IRF(idx:end)=0;
% end
% 
% idx=find(signal_conv==0);
% if numel(idx)>0
% signal_conv(idx:end)=0;
% end

%% smoothing data by avaraging gaps (i.e. zero values)

% signal_conv=(FillTheGap_mean(signal_conv));
% IRF=(FillTheGap_mean(IRF));

%% Generating symmetric distributions 
sym_signal_conv=[signal_conv(end:-1:1),signal_conv];
sym_IRF=[IRF(end:-1:1),IRF];
sym_time=[-numel(signal_conv)*bin_size:bin_size:-1,1:bin_size:numel(signal_conv)*bin_size];%.*tim_int;
%% negative control deconvolution
negative_control_dc=deconvlucy(sym_IRF./trapz(sym_time,sym_IRF),sym_IRF./trapz(sym_time,sym_IRF),deconv_lucy_iteration_number); %d=14 for real data with Gi!!!! very sensitive to this parameter! DO NOT CHANGE!

%negative_control_dc=deconvlucy(sym_IRF./sum(sym_IRF),sym_IRF./sum(sym_IRF),deconv_lucy_iteration_number); %d=14 for real data with Gi!!!! very sensitive to this parameter! DO NOT CHANGE!
negative_control_dc=2*negative_control_dc(1,(end/2+1):end);

%% deconvolve

signal_dc=deconvlucy(sym_signal_conv./trapz(sym_time,sym_signal_conv),sym_IRF./trapz(sym_time,sym_IRF),deconv_lucy_iteration_number); %d=14 for real data with Gi!!!! very sensitive to this parameter! DO NOT CHANGE!
disp('signal_dc')
disp((round(numel(sym_IRF)/2)+1))
disp(size(signal_dc))
signal_dc=2*signal_dc(1,(end/2+1):end);
%% remove trailing zeros from signal_dc if they exist

last_value=find(signal,1,'last');
signal=signal(1:last_value);

last_value=find(signal_conv,1,'last');
signal_conv=signal_conv(1:last_value);

last_value=find(IRF,1,'last');
IRF=IRF(1:last_value);

% last_value=find(signal_dc,1,'last'); %removed in 9v0!!!! check if OK!!!!
% signal_dc=signal_dc(1:last_value);


%% convert to surving interactions over time
signal_ivt=duration2Nvstime(signal);
IRF_ivt=duration2Nvstime(IRF);
signal_conv_ivt=duration2Nvstime(signal_conv);
signal_dc_ivt=duration2Nvstime(signal_dc);
negative_control_dc_ivt=duration2Nvstime(negative_control_dc);
%% exclude last data points for plotting and fitting

signal_ivt=signal_ivt(1:end-exclude_frames);
IRF_ivt=IRF_ivt(1:end-exclude_frames);
signal_conv_ivt=signal_conv_ivt(1:end-exclude_frames);
signal_dc_ivt=signal_dc_ivt(1:end-exclude_frames);
negative_control_dc_ivt=negative_control_dc_ivt(1:end-exclude_frames);

%% normalizing data

negative_control_dc_ivt_norm=negative_control_dc_ivt./max(negative_control_dc_ivt);
signal_conv_ivt_norm=signal_conv_ivt(1:end-exclude_frames)./max(signal_conv_ivt);
signal_dc_ivt_norm=signal_dc_ivt./max(signal_dc_ivt);
IRF_ivt_norm=IRF_ivt./max(IRF_ivt);
signal_ivt_norm=signal_ivt./max(signal_ivt);

%% plotting
if show_plot==1
    disp('show')
ymax=1;
ymin=1.0e-4;
xmin=0;
xmax=fr_show*time_int;
t1 = (0:bin_size:1000).*time_int;

if ~isempty(signal)
h_signal=figure('name', 'signal');
stairs(t1(1:numel(signal)),signal)
xlim([xmin xmax]);
end
%signal,signal_conv,IRF,signal_dc,signal_conv_ivt_norm,signal_ivt_norm,IRF_ivt_norm,signal_dc_ivt_norm
h_signal_conv=figure('name', 'signal_conv');
stairs(t1(1:numel(signal_conv)),signal_conv)
xlim([xmin xmax]);

h_IRF=figure('name', 'IRF');
stairs(t1(1:numel(IRF)),IRF)
xlim([xmin xmax]);

h_signal_dc=figure('name', 'signal_dc');
stairs(t1(1:numel(signal_dc)),signal_dc)
xlim([xmin xmax]);
xlabel('time (sec)')
ylabel('Number of particles')
% 
% h_signal_dc_bar=figure('name', 'signal_dc_bar');
% bar(t1(1:numel(signal_dc)),signal_dc)
% xlim([xmin xmax]);


h_deconvolution_ivt=figure('name', 'deconvolution_ivt');
semilogy (t1(1:numel(signal_conv_ivt_norm)),signal_conv_ivt_norm, 'color','r','displayname',char(groupname_data))
hold on
% semilogy(t1(1:numel(signal_ivt_norm)),signal_ivt_norm, 'color','r','displayname','Data')
semilogy(t1(1:numel(IRF_ivt_norm)),IRF_ivt_norm, 'color','b','displayname',char(groupname_control))
semilogy(t1(1:numel(signal_dc_ivt_norm)),signal_dc_ivt_norm, 'color','g','marker','x','displayname','True interactions')
semilogy(t1(1:numel(negative_control_dc_ivt_norm)),negative_control_dc_ivt_norm, 'color','cyan','displayname','Negative Control')
xlabel('time (sec)')
ylabel('Number of particles')

hold off
ylim([ymin ymax]);
xlim([xmin xmax]);
legend('show')
drawnow

end

%% generate time stamps for fitting

   t2 = 0:numel(signal_dc)-1;
   t2 = t2.*time_int*bin_size;
   t2 = t2';

%% fitting data with exponential decay + non-dissociating RG

%% fitting data with exponential decay

excl_fr_start_0=4; % default=10; for fitting at the beginning (will not fir the 1st 3 points, 1 point is 4 frames - depending on bin_size)
excl_fr_end_0=3; % for fitting at the end (excluding this bit)

signal_dc_fit=signal_dc_ivt_norm';

% h_deconv_fitting=figure ('name','data after deconvolution');
% axes1 = axes('YScale','log','YMinorTick','on');
% xlim(axes1,[0 xmax])
% ylim(axes1,[ymin ymax]);
% hold all
% plot (t2(1:numel(signal_dc_fit)),signal_dc_fit, 'xb')

if numel(t2(excl_fr_start_0+1:end-excl_fr_end_0)) >=15

twoch_model0 = fittype('N*exp(-a*t)+c','independent','t');

options_twoch_model0=fitoptions(twoch_model0);

if fitting_comps==2
options_twoch_model0.Lower = [0  0 0];
options_twoch_model0.Start = [0  0 0]; 
options_twoch_model0.Upper = [1 10 1]; 
end


if fitting_comps==1
options_twoch_model0.Lower = [0  0 0];
options_twoch_model0.Start = [0  0 0]; 
options_twoch_model0.Upper = [1 10 0.000001]; 
end


newfit0=fit(t2(excl_fr_start_0+1:numel(signal_dc_fit)-excl_fr_end_0),signal_dc_fit(excl_fr_start_0+1:end-excl_fr_end_0),twoch_model0,options_twoch_model0);
newfit0_coeff=coeffvalues(newfit0);

N_tot=signal_conv_ivt(1);
real_fraction=newfit0_coeff(1);
no_diss_fraction=newfit0_coeff(3);
N_real=N_tot*real_fraction;

k=newfit0_coeff(2);
k_confint=confint(newfit0);
k_confint=k_confint(:,2);

k_s=k
k_s_confint=k_confint;
k_fr=k*time_int
k_fr_confint=k_confint*time_int;
tau_s=1/k
tau_s_confint=1./k_confint;
tau_fr=1/k_fr
tau_fr_confint=1./k_confint/time_int;

% plot (newfit0, 'k')
% legend ({'raw' 'fit'})

else
    k=NaN;
    k_confint=NaN;
    real_fraction=NaN;
    N_tot=NaN;
    N_real=NaN;
    k_s=NaN;
    k_s_confint=NaN;
    k_fr=NaN;
    k_fr_confint=NaN;
    tau_s=NaN;
    tau_s_confint=NaN;
    tau_fr=NaN;
    tau_fr_confint=NaN;
    
end


hold off

%% correcting for particle loss


k_s_corr=k-kl
k_s_confint_corr=k_confint-kl;
k_fr_corr=(k-kl)*time_int
k_fr_confint_corr=k_s_confint_corr*time_int;
tau_s_corr=1/(k-kl)
tau_s_confint_corr=1./(k_confint-kl);
tau_fr_corr=1/k_fr_corr
tau_fr_confint_corr=1./(k_confint-kl)/time_int;


h_corrected=figure ('name','data after deconvolution and correction for particle loss');
axes1 = axes('YScale','log','YMinorTick','on');
xlim(axes1,[0 xmax])
ylim(axes1,[ymin ymax]);
hold all

if ~isnan(k)
newfit0_f_corr=cfit(newfit0,real_fraction,k-kl,0);
newfit0_exp_comp=cfit(newfit0,real_fraction,k,0);
plot (t2(1:numel(signal_dc_fit)),signal_dc_fit, 'xb')
plot (newfit0, 'k')
plot (newfit0_exp_comp, 'b')
plot (newfit0_f_corr, 'r')
legend ({'raw' 'fit' 'exp component' 'corrected fit'})
hold off
else
    newfit0=[];
    newfit0_f_corr=[];
end




%% estimating receptor/G protein number/density over time, dRG/dt (i.e. rate of new interactions per unit of time), kfor, Kd.

% first calculate the number of receptors and G protein at each frame (they
% decreae due to bleaching)

% number of OBJs over time


    data.krev=k_s_corr;
    data.krev_confint=k_s_confint_corr; %new
    data.real_fraction=real_fraction;
    data.no_diss_fraction=no_diss_fraction;
    
    data.Ch1_free_density=[];
    data.Ch2_free_density=[];
    data.real_density=[];
    data.Ch1_density=[];
    data.Ch2_density=[];
    data.tot_int_rate=[];
    data.real_int_rate=[];
    data.kfor=[];
    data.kd1=[];
    data.kd2=[];
    
for fff=1:numel(filenames_data)
    
    %load ([char(filenames(fff)), '_intmatrix_0pShiftX-0pShiftY-0fShiftT'])
    
    %load ([char(filenames(fff)), '_dr_intmatrix_0pShiftX-0pShiftY-0fShiftT'])
    
    load ([global_folders.rawfolder, filesep, char(filenames_data{fff}), '_intmatrix_0pShiftX-0pShiftY-0fShiftT']) %problem solved 9v0!!!!!
    
    
    %removing duplicate interactions!!!!!
    [Ch(1).OBJ3] = remove_duplicate_ints(Ch(1).OBJ3); %DC: activated on 24/07/2020!!!!
    
    frame_number=frame_num;%max(Ch(1).OBJ3.compound_int_end);
    
    % the number of OBJs over time in each movie
    c=1;
    selected=Ch(c).OBJ.class>0; %only objects inside mask 
    OBJsel_xR=Ch(c).OBJ.xR(selected,1:frame_number);
    for fr=1:frame_number
    data.file(fff).Ch1_OBJ_vs_time(fr)=sum(~isnan(unique(OBJsel_xR(:,fr)))); %here duplicate OBJs are removed
    %data.file(fff).Ch1_OBJ_vs_time(fr)=sum(~isnan(OBJsel_xR(:,fr)));  unique removed meaning duplicates are not removed anymore - 2020-07-03
    end     

    c=2;
    selected=Ch(c).OBJ.class>0; %only objects inside mask 
    OBJsel_xR=Ch(c).OBJ.xR(selected,1:frame_number);
    for fr=1:frame_number
    data.file(fff).Ch2_OBJ_vs_time(fr)=sum(~isnan(unique(OBJsel_xR(:,fr)))); %here duplicate OBJs are removed
    %data.file(fff).Ch2_OBJ_vs_time(fr)=sum(~isnan(OBJsel_xR(:,fr))); %same as Ch1
    end
  
    %the number of total interactions over time in each movie
    for fr=1:frame_number
    %data.file(fff).tot_ints_vs_time(fr)=sum(~isnan(Ch(1).OBJ3.xR(:,fr))); 
    data.file(fff).tot_ints_vs_time(fr)=sum(~isnan(unique(Ch(1).OBJ3.xR(:,fr)))); %removing duplicates
    end
    
    %the number of real interactions over time
    %data.file(fff).real_ints_vs_time=data.file(fff).total_ints_vs_time*real_fraction; %probably wrong!!!!! just remove?!!!!
    
    % the surface area (contained in mask2) in mcm^2
    data.file(fff).area_px=sum(sum(Ch(1).mask2)); %area in pixels^2
    data.file(fff).area=data.file(fff).area_px*pixel_size^2; %area in mcm^2
    
    % the densities - in molecule/mcm^2
    data.file(fff).Ch1_density_vs_time=data.file(fff).Ch1_OBJ_vs_time/data.file(fff).area;
    data.file(fff).Ch2_density_vs_time=data.file(fff).Ch2_OBJ_vs_time/data.file(fff).area; 
    %data.file(fff).real_density_vs_time=data.file(fff).real_ints_vs_time/data.file(fff).area;
    
    data.file(fff).Ch1_density=mean(data.file(fff).Ch1_density_vs_time(interval_average_kon)); % to calculate average densities
    data.file(fff).Ch2_density=mean(data.file(fff).Ch2_density_vs_time(interval_average_kon));
    %data.file(fff).real_density=mean(data.file(fff).real_density_vs_time);
    data.Ch1_density=[data.Ch1_density data.file(fff).Ch1_density];
    data.Ch2_density=[data.Ch2_density data.file(fff).Ch2_density];

    
    % the  rate of new interactions per unit of time at each frame
    % IMPORTANT: the rate of real interactions can be simply calculated by
    % multiplying this by the fraction of real interactions estimated by
    % fitting the deconvovled interaction data!!!!!!!! 
    data.file(fff).tot_int_rate_vs_time=hist(Ch(1).OBJ3.compound_int_start,1:frame_number);
    data.file(fff).real_int_rate_vs_time=data.file(fff).tot_int_rate_vs_time*real_fraction; % nuber of new true interactions at each frame
    data.tot_int_rate=[data.tot_int_rate data.file(fff).tot_int_rate_vs_time];
    data.real_int_rate=[data.real_int_rate data.file(fff).real_int_rate_vs_time];
    
    %the real interactions - now correct!!!!
    data.file(fff).real_density_vs_time=data.file(fff).tot_int_rate_vs_time/data.file(fff).area*data.real_fraction/data.krev/time_int;
    data.file(fff).real_density=mean(data.file(fff).real_density_vs_time(interval_average_kon));

    %coorecting for real interactions
    data.file(fff).Ch1_free_density_vs_time=data.file(fff).Ch1_density_vs_time-data.file(fff).real_density_vs_time;
    data.file(fff).Ch2_free_density_vs_time=data.file(fff).Ch2_density_vs_time-data.file(fff).real_density_vs_time;
    data.file(fff).Ch1_free_density=mean(data.file(fff).Ch1_free_density_vs_time(interval_average_kon)); % to calculate average densities
    data.file(fff).Ch2_free_density=mean(data.file(fff).Ch2_free_density_vs_time(interval_average_kon));
    
    data.Ch1_free_density=[data.Ch1_free_density data.file(fff).Ch1_free_density]; 
    data.Ch2_free_density=[data.Ch2_free_density data.file(fff).Ch2_free_density];
    data.real_density=[data.real_density data.file(fff).real_density];
    
      
    %!!!!! kfor !!!!!
    %Important kfor can be calculated at each frame by dividing the rate of
    %new interactions by both densities. It has dimensions: [mcm^2 * molecule-1 * s-1]; 
    %data.file(fff).kfor_vs_time=data.file(fff).real_int_rate_vs_time/data.file(fff).area./data.file(fff).Ch1_free_density_vs_time./data.file(fff).Ch2_free_density_vs_time/time_int; %original code
    data.file(fff).kfor_vs_time=data.file(fff).real_int_rate_vs_time/data.file(fff).area./data.file(fff).Ch1_free_density./data.file(fff).Ch2_free_density/time_int; %removed _vs_time from Ch1 and Ch2_free density 2020-07-03
    %data.kfor=[data.kfor data.file(fff).kfor_vs_time];
    data.kfor=[data.kfor mean(data.file(fff).kfor_vs_time(interval_average_kon))]; %changed in 9v0!!!!
    
    
    %the Kd based on densities
    data.file(fff).kd1_vs_time=data.file(fff).Ch1_free_density_vs_time.*data.file(fff).Ch2_free_density_vs_time./data.file(fff).real_density_vs_time;
    data.kd1=[data.kd1 data.file(fff).kd1_vs_time];
    
    %the Kd based on kfor and krev
    data.file(fff).kd2_vs_time=data.krev./(data.file(fff).kfor_vs_time(data.file(fff).kfor_vs_time>0));
    data.kd2=[data.kd2 data.file(fff).kd2_vs_time];
   

end  

kfor_temp=data.kfor;% %added for revision

data.list_kfor=kfor_temp;
    data.Ch1_free_density=mean(data.Ch1_free_density);
    data.Ch2_free_density=mean(data.Ch2_free_density);
    
    data.Ch1_density=mean(data.Ch1_density);
    data.Ch2_density=mean(data.Ch2_density);
    data.real_density=mean(data.real_density);
    data.tot_int_rate=mean(data.tot_int_rate);
    data.real_int_rate=mean(data.real_int_rate);
    data.kfor=mean(kfor_temp); %changed in rev
    data.kfor_sd=std(kfor_temp); %changed in rev
    data.kd1=mean(data.kd1(~isinf(data.kd1)));
    data.kd2=mean(data.kd2(~isinf(data.kd2)));
 
    % data.filenames=filenames_control;
    data.filenames_control=filenames_control;
    data.filenames_data=filenames_data;
%  
%% saving data

% start_path='/home/davide/R2009b/data/raw';
% 
% folder_name = uigetdir(analyzedfolderstart_path,'Create folder for saving');

% mkdir()

cd(save_path)%folder_name)


signal_conv_d=[];
for f=1:numel(filenames_control)  
    load ([global_folders.rawfolder, filesep, char(filenames_control(f)), '_intmatrix2'])
    signal_conv_d=[signal_conv_d shift(1).compound_ints_durations]; 
end

signal_conv_d=signal_conv_d(signal_conv_d<duration_max);

signal_conv=hist(signal_conv_d,1:bin_size:max(signal_conv_d)); %the distribution of colocalizations of different time

clear k;



mkdir ([global_folders.deconvolution_folder, filesep, filenamesave])
% cd (filenamesave)

save ([global_folders.deconvolution_folder, filesep, filenamesave, filesep, filenamesave, '-data'],'data','bin_size','duration_max', 'signal*', 'negative_control*','IRF*', 't1', 't2', 'time_int', 'newfit0', 'newfit0_f_corr','N_tot', 'real_fraction', 'N_real', 'k*', 'tau*', 'searchRadius', '-v7.3');

saveas(h_signal_conv, [global_folders.deconvolution_folder, filesep, filenamesave, filesep, filenamesave, '-signal_conv'],'fig');
saveas(h_IRF, [global_folders.deconvolution_folder, filesep, filenamesave, filesep, filenamesave, '-IRF'],'fig');
saveas(h_signal_dc, [global_folders.deconvolution_folder, filesep, filenamesave, filesep, filenamesave, '-signal_dc'],'fig');
%saveas(h_signal_dc_bar,'signal_dc_bar','fig');

saveas(h_deconvolution_ivt, [global_folders.deconvolution_folder, filesep, filenamesave, filesep, filenamesave, '-deconvolution_ivt'],'fig');
saveas(h_corrected, [global_folders.deconvolution_folder, filesep, filenamesave, filesep, filenamesave, '-corrected'],'fig');

if ~isempty(signal)
saveas(h_signal, [global_folders.deconvolution_folder, filesep, filenamesave, filesep, filenamesave, '-signal'],'fig');
end


%%

% to estimate the rate constant for random colocalizations + non productive
% interactions for revision!!!

% for fff=1:numel(data.filenames)
% kfor_collision_non_prod(fff)=mean(data.file(fff).tot_int_rate_vs_time*(1-real_fraction)/data.file(fff).area./data.file(fff).Ch1_free_density_vs_time./data.file(1).Ch2_free_density_vs_time/time_int);
% 
% kfor_collision_non_prod_2(fff)=mean(data.file(fff).tot_int_rate_vs_time)*(1-real_fraction)/data.file(fff).area./mean(data.file(fff).Ch1_free_density_vs_time)./mean(data.file(1).Ch2_free_density_vs_time)/time_int;
% 
% 
% end
% figure
% hist(kfor_collision_non_prod_2)
% mean(kfor_collision_non_prod)
% sd(kfor_collision_non_prod)



end

