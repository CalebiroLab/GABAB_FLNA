% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
%% parameters
parameter=struct;
parameter.pixel_size=160;%nanometer
parameter.pixel_size_um=parameter.pixel_size/1000;%pixel size in micrometer

parameter.wavelength_channel=[670,571,510];%[637,561,488]; % excitation wavelength
parameter.numerical_aperture=1.45; % numerical aperture
parameter.FrameNumber=400;% number of frame to be analysed
parameter.Frameduration=0.03;% duration of a frame in second

parameter.min_traj_length=3;

%% parameter trapping detection

parameter.p_val_traj_type='fBm'; % can be 'Bm' or 'fBm'
parameter.T_mean=2; % must stay 2
parameter.sig_noise=0; % must stay 0
parameter.diag_percentile=10;% can be 0,5,10 or 50
parameter.nu=0.75; % can be 0.1,0.3,0.5,0.75,0.9,1; 0.75 is recommended
parameter.p_value=0.05; % can be any percentile (minimum 0.01)
parameter.list_mu=[1:0.5:2]; % maximum range ([0.5,1,1.5,2,2.5,3])


%% Interaction analysis
parameter.searchRadius=150;%nm
parameter.frame_number_interaction_analysis=400;
parameter.list_interaction_couple=[1,2];

%% type of datactructure to be used
parameter.data_type_list={'_gui2_steps.mat','_intmatrix_0pShiftX-0pShiftY-0fShiftT.mat','-C1-C2_OBJswap_after_interaction.mat'};
parameter.data_type=parameter.data_type_list{1,1};% <=== HERE select 1,2, or 3 for different data type according to parameter.data_type_list

% inMask
%                     'state_name','file suffix.format','position of the
%                     transformation piecewise linear param'(nan for no alignement)
parameter.mask_pairs={'inCCP','_stack_binary_mask_CCP.mat',3;...
                        'inActin','-actin_msk2.tif',nan};


                    

%% parameter inCCP
parameter.threshold_inCCP=1; % threshold, number of standard deviations beyond which the deconvolved pixels are considered as CCP
parameter.min_side_peak_CCP=3;
parameter.Kalman_Filter_gain=0.9; %Gain  for Kalman Filter (denoising)
parameter.CCP_frame_average=50;
parameter.CCP_minimum_pixel_num_CCP=4;
parameter.disk_rad_CCP=1;

        %% PSF for deconvolution of CCP images

        Ltest=10;
        resolution_CCP=parameter.wavelength_channel(1,3)/(2*parameter.numerical_aperture)/parameter.pixel_size;
          xtest=linspace(-3*ceil(resolution_CCP),3*ceil(resolution_CCP),6*ceil(resolution_CCP));
        [Ytest,Xtest] = ndgrid(xtest);
        exponent = ((Xtest).^2 + (Ytest).^2)./(2* resolution_CCP^2);
        PSF= exp(-exponent);
        parameter.PSF_CCP_deconv=PSF./sum(sum(PSF));
        clearvars Ltest sigma_test xtest Ytest Xtest exponent resolution_CCP PSF

parameter.ccp_background_disk=5;

%% parameters for flipping states
parameter.minimal_state_duration=3;

%% parameter for Markov Chain
parameter.markov_chain_Nmax=200;
parameter.sup_dur=10;% minimum duration of a state in markov_chain_supdur
%% parameter for analysis
parameter.name_state={'outsideCCP','insideCCP';...
    'free','trapped';...
    'single','colocalisation'};

parameter.selected_states=[1;1;1]; %(CCP,trapped,coloc)


%% Complete list states after 06/12/2019
% flipped :> CCP | istrapped | interaction
parameter.state_vec_fields={'trapped','on_membrane'}; % which fields of list_states are used in which order for state number attribution



% %% List of states
parameter.state{1,1}="Absent";%"cytosol";%"+newline+"
parameter.state{1,2}={[-1;0]};
parameter.state{1,3}={[]};
parameter.state{1,4}='$$\emptyset\;\, -\;\,\emptyset$$';

parameter.state{2,1}="Free";%"visiting CCP";
parameter.state{2,2}={[0;1]};
parameter.state{2,3}={[],[]};
parameter.state{2,4}='F $$-\;\,\emptyset$$';

parameter.state{3,1}="Confined";
parameter.state{3,2}={[1;1]};
parameter.state{3,3}={[]};
parameter.state{3,4}='T $$-\;\,\emptyset$$';



%%

% parameter.color_map=...
%     [200,200,200;...%1 grey
%     100,255,255;...% %free
%     150,0,0;...% %confined
%     0,0,255;...% blue %codiffusion
%     0,255,0]./255;% magenta %cotrapped
parameter.color_map=...
    [200,200,200;...%1 grey
    100,255,255;...% %free
    150,0,0;...% %confined
    0,0,255;...% blue %codiffusion
    200,200,100;... %    %free coloc trapped
    0,255,0;...% magenta %cotrapped
    0,255,100]./255;%;...% green % trapped coloc free


%% merging state for history before CCP

parameter.state_inCCP=[8,9];
 %% merging states when partner is not in same state
  parameter.merging_state.history_before_CCP={};
%  parameter.merging_state.history_before_CCP{1,1}=4;
% parameter.merging_state.history_before_CCP{1,2}=2;
% 
%  parameter.merging_state.history_before_CCP{2,1}=7;
% parameter.merging_state.history_before_CCP{2,2}=5;
% 
%  parameter.merging_state.history_before_CCP{3,1}=10;
% parameter.merging_state.history_before_CCP{3,2}=8;

%% merging state for history before CCP % no trapping
% parameter.merging_state.history_before_CCP{1,1}=4;
% parameter.merging_state.history_before_CCP{1,2}=3;
% parameter.merging_state.history_before_CCP{2,1}=5;
% parameter.merging_state.history_before_CCP{2,2}=2;
% parameter.merging_state.history_before_CCP{3,1}=6;
% parameter.merging_state.history_before_CCP{3,2}=3;
% parameter.merging_state.history_before_CCP{4,1}=7;
% parameter.merging_state.history_before_CCP{4,2}=3;
% % parameter.merging_state.history_before_CCP{5,1}=10;
% % parameter.merging_state.history_before_CCP{5,2}=9;
% 
% parameter.merging_state.history_before_CCP{1,1}=4;
% parameter.merging_state.history_before_CCP{1,2}=2;
% parameter.merging_state.history_before_CCP{2,1}=5;
% parameter.merging_state.history_before_CCP{2,2}=2;
% parameter.merging_state.history_before_CCP{3,1}=6;
% parameter.merging_state.history_before_CCP{3,2}=3;
% parameter.merging_state.history_before_CCP{4,1}=7;
% parameter.merging_state.history_before_CCP{4,2}=2;
%  parameter.merging_state.history_before_CCP{5,1}=10;
%  parameter.merging_state.history_before_CCP{5,2}=8;

%%  new version of 

%parameter.interacting_states=[3,4,6,7,9,10];
parameter.interacting_states=[4,5,6,7];
%%
parameter.min_interaction_duration=10;
% 
% 
% parameter.merging.state.trapped_CCP{1,1}=4;
% parameter.merging.state.trapped_CCP{1,2}=2;
% 
% parameter.merging.state.trapped_CCP{2,1}=3;
% parameter.merging.state.trapped_CCP{2,2}=2;
% 
% parameter.merging.state.trapped_CCP{3,1}=6;
% parameter.merging.state.trapped_CCP{3,2}=5;
% 
% parameter.merging.state.trapped_CCP{4,1}=7;
% parameter.merging.state.trapped_CCP{4,2}=5;
% 
% parameter.merging.state.trapped_CCP{5,1}=9;
% parameter.merging.state.trapped_CCP{5,2}=10;
% 
%  parameter.merging.state.trapped_CCP{6,1}=10;
%  parameter.merging.state.trapped_CCP{6,2}=8;
%% 
parameter.merging.state.trapped_CCP={};
% parameter.merging.state.trapped_CCP{1,1}=4;
% parameter.merging.state.trapped_CCP{1,2}=2;
% 
% parameter.merging.state.trapped_CCP{2,1}=3;
% parameter.merging.state.trapped_CCP{2,2}=2;
% 
% parameter.merging.state.trapped_CCP{3,1}=7;
% parameter.merging.state.trapped_CCP{3,2}=5;
% 
% parameter.merging.state.trapped_CCP{4,1}=6;
% parameter.merging.state.trapped_CCP{4,2}=5;
% 
% parameter.merging.state.trapped_CCP{5,1}=10;
% parameter.merging.state.trapped_CCP{5,2}=8;
% 
% parameter.merging.state.trapped_CCP{6,1}=9;
% parameter.merging.state.trapped_CCP{6,2}=8;
% 
% parameter.merging.state.trapped_CCP{7,1}=1;
% parameter.merging.state.trapped_CCP{7,2}=nan;

 

%% make a list of kept states
% parameter.list_kept_state=zeros(size(parameter.state,1),1);
% if ~isempty(parameter.merging_state)
%     for n=1:size(parameter.merging_state,1)
% parameter.list_excluded(parameter.merging_state{n,2},1)=1;
%     end
% end


%% TAMSD analysis

parameter.TAMSD.min_traj_length=50;
parameter.TAMSD.MinWindowSize=1;
parameter.TAMSD.MaxWindowSize=5;
parameter.TAMSD.localisation_error_std=20/parameter.pixel_size; %20nm 
