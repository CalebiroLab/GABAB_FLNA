% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
%% Windows computer - Linux data folder mounted under Y drive
global_folders=struct;

    global_folders.rawfolder = '/media/data_drive/data/project_marielise/project_MLJ_SYN_EXSYN/rawdata_MLJ_SYN_EXSYN';
    global_folders.localfolder = '/media/data_drive/data/temp';
    global_folders.MSDfolder = '/media/data_drive/data/project_marielise/project_MLJ_SYN_EXSYN/msd_MLJ_SYN_EXSYN';
    global_folders.MSD_groups = '/media/data_drive/data/project_marielise/project_MLJ_SYN_EXSYN/msd_MLJ_SYN_EXSYN';
    global_folders.state_analysis_folder= '/media/data_drive/data/project_marielise/project_MLJ_SYN_EXSYN/state_analysis_MLJ_SYN_EXSYN';
    global_folders.beta_arr_project_result='/media/data_drive/data/project_marielise/project_MLJ_SYN_EXSYN/project_result_MLJ_SYN_EXSYN';
