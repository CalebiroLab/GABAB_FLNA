% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
clear;
close all;
global_folders_SYN_EXSYN;
movie_list_BX;
parameter_list_BX;

group_names = fieldnames(movie_list);

movie_name_list={};
for n_group=numel(group_names)-3:numel(group_names)
    movie_name_list= [movie_name_list,movie_list.(group_names{n_group})];
end
moviename=movie_name_list;
list_error={};
for channel_number=1
    n_error=0;
    for n_mov=1:numel(moviename)
       % try
            disp(['computing ',moviename{n_mov},'-C',num2str(channel_number)])
            min_traj_duration=120;
            max_window=42;
    %        starMSD_v9_msk_YL(moviename{n_mov}, channel_number,400,min_traj_duration,max_window, parameter, global_folders);
    starMSD_v9_msk_frame_interval(moviename{n_mov}, channel_number,[1,400],min_traj_duration,max_window, parameter, global_folders);
    
            close all
%         catch e
%             n_error=n_error+1;
%             list_error{n_error,1}=e;
%             disp(['Error: ',e.message])
%         end
    end
end
