% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
% List of all the conditions tested for single molecule data
movie_list=struct;%creation of empty structure

%% SYN

% GABABwt - Homer - Basal

movie_list.GABAwt_Homer_Basal_SYN={'MLJBX042','MLJBX044','MLJBX046','MLJBX065','MLJBX090','MLJBX092'};


% GABABwt - Homer - Stimulated

movie_list.GABAwt_Homer_Stim_SYN={'MLJBX067','MLJBX070','MLJBX071','MLJBX072','MLJBX075','MLJBX076','MLJBX077','MLJBX091'};

% GABABwt - Bassoon - Basal

movie_list.GABAwt_Bassoon_Basal_SYN={'MLJBX048','MLJBX049','MLJBX052','MLJBX054','MLJBX080','MLJBX082'};

% GABABwt - Bassoon - Stimulated

movie_list.GABAwt_Bassoon_Stim_SYN={'MLJBX079','MLJBX085','MLJBX084','MLJBX097','MLJBX099','MLJBX100'};



 group_names=fieldnames(movie_list);
   
for n_cond=1:4
 
 for n_movie=1:numel(movie_list.(group_names{n_cond}))
    movie_list.(group_names{n_cond}){1,n_movie}=[movie_list.(group_names{n_cond}){1,n_movie},'-SYN'];
     end
end



%% EXSYN

% GABABwt - Homer - Basal

movie_list.GABAwt_Homer_Basal_EXSYN={'MLJBX042','MLJBX044','MLJBX046','MLJBX065','MLJBX090','MLJBX092'};

% GABABwt - Homer - Stimulated

movie_list.GABAwt_Homer_Stim_EXSYN={'MLJBX067','MLJBX070','MLJBX071','MLJBX072','MLJBX075','MLJBX076','MLJBX077','MLJBX091'};

% GABABwt - Bassoon - Basal

movie_list.GABAwt_Bassoon_Basal_EXSYN={'MLJBX048','MLJBX049','MLJBX052','MLJBX054','MLJBX080','MLJBX082'};

% GABABwt - Bassoon - Stimulated

movie_list.GABAwt_Bassoon_Stim_EXSYN={'MLJBX079','MLJBX085','MLJBX084','MLJBX097','MLJBX099','MLJBX100'};
group_names=fieldnames(movie_list);
   
for n_cond=5:8
 
 for n_movie=1:numel(movie_list.(group_names{n_cond}))
    movie_list.(group_names{n_cond}){1,n_movie}=[movie_list.(group_names{n_cond}){1,n_movie},'-EXSYN'];
     end
end

%% Dyngo to prevent internalisation

%% Synaptic
% GABABwt - Homer +Dyngo4A - Basal

% 220511  MLJBX101 > MLJBX105

movie_list.GABAwt_Homer_Basal_SYN_Dyngo={'MLJBX101','MLJBX102','MLJBX103','MLJBX104','MLJBX105','MLJBX112','MLJBX113','MLJBX114','MLJBX119','MLJBX120','MLJBX121','MLJBX122','MLJBX123','MLJBX124','MLJBX125','MLJBX126','MLJBX127','MLJBX128','MLJBX129','MLJBX130'};

% GABABwt - Homer +Dyngo4A - Stimulated

% 220511 MLJBX106 > MLJBX111

movie_list.GABAwt_Homer_Stim_SYN_Dyngo={'MLJBX106','MLJBX107','MLJBX108','MLJBX109','MLJBX110','MLJBX111','MLJBX115','MLJBX116','MLJBX117','MLJBX118','MLJBX131','MLJBX132','MLJBX133','MLJBX134','MLJBX135','MLJBX136','MLJBX137'};


group_names=fieldnames(movie_list);
   
for n_cond=9:10
 
 for n_movie=1:numel(movie_list.(group_names{n_cond}))
    movie_list.(group_names{n_cond}){1,n_movie}=[movie_list.(group_names{n_cond}){1,n_movie},'-SYN'];
     end
end

%% Extrasynaptic

% GABABwt - Homer +Dyngo4A - Basal
% 220511  MLJBX101 > MLJBX105

movie_list.GABAwt_Homer_Basal_EXSYN_Dyngo={'MLJBX101','MLJBX102','MLJBX103','MLJBX104','MLJBX105','MLJBX112','MLJBX113','MLJBX114','MLJBX119','MLJBX120','MLJBX121','MLJBX122','MLJBX123','MLJBX124','MLJBX125','MLJBX126','MLJBX127','MLJBX128','MLJBX129','MLJBX130'};

% GABABwt - Homer +Dyngo4A - Stimulated

% 220511 MLJBX106 > MLJBX111

movie_list.GABAwt_Homer_Stim_EXSYN_Dyngo={'MLJBX106','MLJBX107','MLJBX108','MLJBX109','MLJBX110','MLJBX111','MLJBX115','MLJBX116','MLJBX117','MLJBX118','MLJBX131','MLJBX132','MLJBX133','MLJBX134','MLJBX135','MLJBX136','MLJBX137'};




group_names=fieldnames(movie_list);
   
for n_cond=11:12
 
 for n_movie=1:numel(movie_list.(group_names{n_cond}))
    movie_list.(group_names{n_cond}){1,n_movie}=[movie_list.(group_names{n_cond}){1,n_movie},'-EXSYN'];
     end
end
