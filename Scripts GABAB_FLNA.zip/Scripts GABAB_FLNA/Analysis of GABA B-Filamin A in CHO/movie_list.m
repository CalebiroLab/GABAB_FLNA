% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
%List of all the conditions tested for single molecule data
movie_list=struct;%creation of empty structure

%% GABABwt - FLNA -- basal

%180710		MLJ079 > MLJ084
%180807		MLJ093 > MLJ109
%180809		MLJ110 > MLJ127
%180821		MLJ148 > MLJ158

movie_list.GABAwt_FLNA_basal={'MLJ078','MLJ079','MLJ080','MLJ082','MLJ083',...
'MLJ084','MLJ110','MLJ111','MLJ112','MLJ113','MLJ114','MLJ115','MLJ116'...
,'MLJ117','MLJ118','MLJ119','MLJ120','MLJ121','MLJ122','MLJ123','MLJ124'...
,'MLJ125','MLJ126','MLJ127','MLJ093','MLJ094','MLJ095','MLJ096','MLJ097'...
,'MLJ098','MLJ099','MLJ100','MLJ101','MLJ102','MLJ103','MLJ104','MLJ105'...
,'MLJ106','MLJ107','MLJ108','MLJ148','MLJ149','MLJ150','MLJ151'...
,'MLJ152','MLJ153','MLJ154','MLJ155','MLJ156','MLJ157','MLJ158'};
%Removed: ,'MLJ081','MLJ109'

%n_mov=numel(movie_list.GABAwt_FLNA_basal);
movie_list.GABAwt_FLNA_basal=movie_list.GABAwt_FLNA_basal(1:2:end);


%% GABABwt - FLNA -- stimulated

%180814	MLJ128 > MLJ138
%180816	MLJ139 > MLJ147

movie_list.GABAwt_FLNA_stim={'MLJ128','MLJ129','MLJ130','MLJ131','MLJ132','MLJ133',...
'MLJ134','MLJ135','MLJ136','MLJ137','MLJ138','MLJ139','MLJ140','MLJ141'...
,'MLJ142','MLJ143','MLJ144','MLJ145','MLJ146','MLJ147'};
%removed 
%% GABABmutant - FLNA -- basal

%181005	MLJ159 > MLJ167
%181010	MLJ168 > MLJ177
%181016	MLJ181 > MLJ184

movie_list.GABAmut_FLNA_basal={'MLJ159','MLJ160','MLJ161','MLJ162','MLJ163','MLJ164',...
'MLJ165','MLJ166','MLJ167','MLJ169','MLJ170','MLJ171','MLJ172'...
,'MLJ173','MLJ174','MLJ175','MLJ176','MLJ177','MLJ181','MLJ182','MLJ183'...
,'MLJ184'};%,'MLJ168'

%% GABABmutant - FLNA -- stimulated

%181010	MLJ178 > MLJ180
%181016	MLJ185 > MLJ193

movie_list.GABAmut_FLNA_stim={'MLJ178','MLJ179','MLJ180','MLJ185','MLJ186','MLJ187',...
'MLJ188','MLJ189','MLJ190','MLJ191','MLJ192','MLJ193'};
