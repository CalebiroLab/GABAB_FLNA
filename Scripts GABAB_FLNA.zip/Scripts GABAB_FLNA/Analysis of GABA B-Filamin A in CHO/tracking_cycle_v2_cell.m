% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
function tracking_cycle_v2_cell (movie_list,list_channel,parameter, global_folders)
close all;
movie_fields=fieldnames(movie_list);
movie_fields=movie_fields;%(end:-1:1);
for n_group=1:numel(movie_fields)
    disp ([movie_fields{n_group,1}, ' OK']);
    automated_tracking(movie_fields{n_group,1}, 400, list_channel,movie_list, parameter,global_folders)
end
end

%%
function automated_tracking (group, Frames,list_channel, movie_list,parameter, global_folders)

moviename = movie_list.(group);
%moviename=moviename(end:-1:1);
% moviename = strsplit(eval(group),' ');
n=numel(moviename);
channel={'-C1', '-C2'};
list_of_file={'_gui2_steps.mat', '_MSD.csv'};
list_not_working={};
for nfile=1%:numel(list_of_file)
    for nmov=1:n
        for ch=list_channel
            path = [global_folders.rawfolder, filesep];
            mov_name=[moviename{1,nmov},channel{1,ch}];
            entire_path=[path,mov_name, list_of_file{1,nfile}];
            if exist(entire_path)~= 0
                disp ([mov_name,' OK ', list_of_file{1,nfile}]); %this checks if each file with the given category (e.g. gui2 steps, MSD.csv, .avi) exist and displays OK if it does
            else
                if strcmp(list_of_file{1,nfile},'_gui2_steps.mat')==1
                    disp ([mov_name,' NO gui2_steps'])
                    try
                        % disp ('tracking...')
                        % pause (3)
                        tracking_MSD (mov_name, Frames, parameter,global_folders);
                    catch e
                        list_not_working{size(list_not_working,1)+1,1}=mov_name;
                        list_not_working{size(list_not_working,1),2}=list_of_file{1,nfile};
                        list_not_working{size(list_not_working,1),3}=e;
                        save ([mov_name, '_tracking_not_working'], 'list_not_working');
                    end
                elseif strcmp(list_of_file{1,nfile},'_MSD.csv')==1
%                     try
%                         disp([mov_name, ' no MSD file']);
%                         mov_name_MSD=mov_name(1:end-3); % to delete the channel number for MSD script later
%                         channel_number=string((mov_name(end))); % for MSD script below
%                         channel_number=str2double(channel_number);
%                         starMSD_4v7_ZK(mov_name_MSD, channel_number, Frames, parameter, global_folders);
%                                                 
%                         %starMSD_4v6_ZK (mov_name, Frames, global_folders);
%                         disp([mov_name,' MSD computed'])
%                     catch e
%                         list_not_working{size(list_not_working,1)+1,1}=mov_name;
%                         list_not_working{size(list_not_working,1),2}=list_of_file{1,nfile};
%                         list_not_working{size(list_not_working,1),3}=e;
%                         save ([mov_name, '_MSD_not_working'], 'list_not_working');
%                     end
                end
            end
        end
    end
end
end
