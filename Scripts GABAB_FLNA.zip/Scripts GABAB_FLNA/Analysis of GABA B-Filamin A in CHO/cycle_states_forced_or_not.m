% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)

%% Script that runs over all the conditions and creates list of states for each of them
clear;
close all;
global_folders;
movie_list;
parameter_list;

list_not_working={};
%% list of channels
list_channel=[1,2];
%% list of interaction couples

list_interaction_couple=[1,2];

%% loop that generates the name of each condition and input it in automated_list_of_states_forced_or_not_v11


to_be_computed.exist=1;
to_be_computed.trapped=1;
to_be_computed.interaction=1;
to_be_computed.flipped=1;
to_be_computed.on_membrane=1;
to_be_computed.state_number=1;
to_be_computed.markov_chain_forward=1;
to_be_computed.markov_chain_forward_supdur=1;




test.forced=0;
test.exist=0;
test.trapped=0;
test.interaction=0;
test.flipped=0;
test.on_membrane=0;
test.state_number=0;
test.markov_chain_forward=0;
test.markov_chain_forward_supdur=0;


group_names = fieldnames(movie_list);

movie_name_list={};
for n_group=1:numel(group_names)
    movie_name_list= [movie_name_list,movie_list.(group_names{n_group})];
end
moviename=movie_name_list;

[not_working]=automated_list_of_states_forced_or_not(moviename,to_be_computed,test,list_channel,list_interaction_couple,parameter,global_folders);

list_not_working(size(list_not_working,1)+1:size(list_not_working,1)+size(not_working,1),1:3)=not_working;

save([global_folders.state_analysis_folder,filesep,'list_not_working_state_analysis.mat'],'list_not_working')
