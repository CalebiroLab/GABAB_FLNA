% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
% where does beta arrives when it arrives.

% Create transotion matrix from list binary of state
clear;
close all;
%figure

global_folders;
movie_list;
parameter_list;
group_names = fieldnames(movie_list);

N=1000;
save_im=1;
%% list of all the variables
channel={'C1','C2'};

list_sequence={};


list_state_exist=ones(size(parameter.state,1),1);
for i=1: size(parameter.merging_state.history_before_CCP,1)
    list_state_exist(parameter.merging_state.history_before_CCP{i,1},1)=0;
end
list_state_exist(1,1)=0;
list_state_exist_index=find(list_state_exist==1);

for i=1:size(parameter.state,1)
    list_name(1,i)=parameter.state{i,1};
end
%figure;imagesc((1:10)');yticklabels(list_name);colormap(parameter.color_map)
list_state_interact_name=list_name(1,parameter.interacting_states);

%% combining all transition matrices
 cp_group=0;
for n_group=1:numel(group_names)
    group=group_names{n_group};
    if isfield(movie_list,group)
        cp_group=cp_group+1;
        movie_name = movie_list.(group);
        for ch=1:2
            %                 list_perc_interaction_all=cell(numel(stim_duration),numel(parameter.interacting_states));
            %                 list_perc_interaction_all_std_error=cell(numel(stim_duration),numel(parameter.interacting_states));
            %
            cp_traj=0;
            
            
            list_perc_interaction=zeros(numel(movie_name),numel(list_state_exist_index));
              list_interaction_count=zeros(numel(movie_name),numel(list_state_exist_index));
           
            cp=0;
            for n_mov=1:numel(movie_name)
                disp([group,'_',channel{1,ch},' movie ',num2str(n_mov),'/',num2str(numel(movie_name))]);
                
                if isfile([global_folders.state_analysis_folder,filesep,movie_name{1,n_mov},'-',channel{1,ch},'_list_state.mat'])==1
                    load([global_folders.state_analysis_folder,filesep,movie_name{1,n_mov},'-',channel{1,ch},'_list_state.mat'])
                    if isfield(list_state,'state_number')
                        
                        
                        
                        cp_interact=0;
                        list_state_test=[list_state.state_number,nan(size(list_state.state_number,1),1)]';
                        test=all(isnan(list_state_test),1);
                        list_state_test(:,test)=[];
                       
                                [state_vector_unique] = make_state_unique_nrep(list_state_test(:)');
                                state_vector_unique(:,isnan(state_vector_unique(1,:)))=[];
                        for state_interact_num=list_state_exist_index'
                            cp_interact=cp_interact+1;
                    parameter.min_interaction_duration=10;
                            test_vec=state_vector_unique(1,:)==state_interact_num & state_vector_unique(2,:)>=parameter.min_interaction_duration;
                            
                            list_perc_interaction(n_mov,cp_interact)=sum(state_vector_unique(2,test_vec));
                            list_interaction_count(n_mov,cp_interact)=sum(state_vector_unique(1,test_vec));
                            
                        end
                    end
                else
                    disp([movie_name{1,n_mov},'-',channel{1,ch},'_ no.flipped'])
                    
                end
            end
            
            
            %list_perc_interaction= list_perc_interaction./repmat(sum(list_perc_interaction,2),1,numel(parameter.interacting_states));
            n_number=sum(sum( list_perc_interaction));
            for n_s1=1:size(list_perc_interaction,2)
                list_perc_interaction_all{n_s1,1}=sum(list_perc_interaction(:,n_s1));%/n_number;
                list_perc_interaction_all_std_error{n_s1,1}=list_perc_interaction_all{n_s1,1}*(1-list_perc_interaction_all{n_s1,1})/sqrt(n_number);
            end
            
            %%
        if save_im==1
             save([global_folders.beta_arr_project_result,filesep,'list_perc_interaction_all_',group,'-',channel{1,ch},'_allstate.mat'],'list_perc_interaction','list_perc_interaction_all','list_perc_interaction_all_std_error','list_state_interact_name','list_interaction_count')
        end
        clearvars list_perc_interaction_all list_perc_interaction_all_std_error
         end
        %                 image_markov=getframe(gcf);
        %                 imwrite(image_markov.cdata,['percentage_state_bef_aft_stim_distrib_start_',receptor{1,n_rec},'-',arrestin{1,n_arr},'-',channel{1,ch},'.jpg'],'jpg')
        %
    end
end
