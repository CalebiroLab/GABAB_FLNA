% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
clear;
close all;

movie_list;
global_folders;
parameter_list;

%tracking_cycle_v2 (movie_list, global_folders, parameter);
interaction_cycle_v1(movie_list,parameter, global_folders);
OBJ_swapping_cycle_v2(movie_list,parameter, global_folders);
%MSD_cycle (movie_list, global_folders, parameter);
