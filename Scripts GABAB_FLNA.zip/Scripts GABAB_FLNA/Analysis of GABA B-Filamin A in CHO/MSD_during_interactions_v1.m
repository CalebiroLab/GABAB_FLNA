% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
% where does beta arrives when it arrives.

% Create transotion matrix from list binary of state
clear;
close all;
%figure

global_folders;
movie_list;
parameter_list;
group_names = fieldnames(movie_list);
list_name_molecule={'receptor','filamin'};
N=1000;
save_im=1;
save_path='/media/data_drive/data/project_marielise/project_GABA_Filamin/project_result_GABA_Filamin/D and alpha as function of coloc state';
%% list of all the variables
channel={'C1','C2'};

list_sequence={};


list_state_exist=ones(size(parameter.state,1),1);
for i=1: size(parameter.merging_state.history_before_CCP,1)
    list_state_exist(parameter.merging_state.history_before_CCP{i,1},1)=0;
end
list_state_exist(1,1)=0;
list_state_exist_index=find(list_state_exist==1);
list_state_interact=4:7;


for i=1:size(parameter.state,1)
    list_name(1,i)=parameter.state{i,1};
end
%figure;imagesc((1:10)');yticklabels(list_name);colormap(parameter.color_map)
list_state_interact_name=list_name(1,parameter.interacting_states);

%% combining all transition matrices
cp_group=0;
for n_group=1:numel(group_names)
    group=group_names{n_group};
    if isfield(movie_list,group)
        cp_group=cp_group+1;
        movie_name = movie_list.(group);
        
        %                 list_perc_interaction_all=cell(numel(stim_duration),numel(parameter.interacting_states));
        %                 list_perc_interaction_all_std_error=cell(numel(stim_duration),numel(parameter.interacting_states));
        %
        cp_traj=0;
        
        
        list_perc_interaction=zeros(numel(movie_name),numel(list_state_exist_index));
        list_interaction_count=zeros(numel(movie_name),numel(list_state_exist_index));
        
        cp=0;
        for n_mov=1:numel(movie_name)
            [Ch] = load_data_XY_v1(movie_name{1,n_mov},[1,2],parameter,global_folders);
            for ch=1:2
               disp([group,'_',channel{1,ch},' movie ',num2str(n_mov),'/',num2str(numel(movie_name))]);
             
                Ch(ch).OBJ.yR(Ch(ch).OBJ.yR<1)=nan;
                Ch(ch).OBJ.xR(Ch(ch).OBJ.xR<1)=nan;
                
                if isfile([global_folders.state_analysis_folder,filesep,movie_name{1,n_mov},'-',channel{1,ch},'_list_state.mat'])==1
                    load([global_folders.state_analysis_folder,filesep,movie_name{1,n_mov},'-',channel{1,ch},'_list_state.mat'])
                    if isfield(list_state,'state_number')
                        
                        
                        
                        list_state_test=[list_state.state_number,nan(size(list_state.state_number,1),1)]';
                        test=all(isnan(list_state_test),1);
                        list_state_test(:,test)=[];
                        list_state_test=list_state_test(:);
                        
                        X=[Ch(ch).OBJ.xR,nan(size(list_state.state_number,1),1)]';
                        X(:,test)=[];
                        Y=[Ch(ch).OBJ.yR,nan(size(list_state.state_number,1),1)]';
                        Y(:,test)=[];
                        X=X(:);Y=Y(:);
                        %% %%%%%%%%%%%%%%
                        I=isnan(X);
                        I2=diff([I(1);I]);
                        list=sort([find(~I);find(I2>0)],'ascend'); 
                        X=X(list);
                        Y=Y(list);
                        list_state_test=list_state_test(list);
                        %% %%%%%%%%%%%%%
                        [state_vector_unique] = make_state_unique_nrep(list_state_test');
                        state_vector_unique(3,:)=cumsum(state_vector_unique(2,:));
                        state_vector_unique=[[0;0;0],state_vector_unique];
                        %state_vector_unique(:,isnan(state_vector_unique(1,:)))=[];
                        list_MSD_param=cell(4,1);
                        cp_interact=0;
                        for state_interact_num=list_state_interact
                            cp_interact=cp_interact+1;
                            parameter.min_interaction_duration=10;
                            
                            list_pres=find(state_vector_unique(1,:)==state_interact_num);
                            list_min_max=[state_vector_unique(3,list_pres-1)'+1,state_vector_unique(3,list_pres)'];
                            
                            list_min_max((list_min_max(:,2)-list_min_max(:,1)+1)<parameter.TAMSD.min_traj_length,:)=[];
                            
                            fit_param=nan(size(list_min_max,1),3);
                            if size(list_min_max,1)>0
                                for n=1:size(list_min_max,1)
                                    
                                    X_int=X(list_min_max(n,1):list_min_max(n,2));
                                    Y_int=Y(list_min_max(n,1):list_min_max(n,2));
                                    [list_TAMSD] = TAMSD_Trajectory( X_int,Y_int,parameter );
                                    list_TAMSD=sum(list_TAMSD,2)-4*parameter.TAMSD.localisation_error_std.^2;
%                                     if ismember(state_interact_num,[4,5])
                                    [fit_param(n,:) ] = NonLinearFitTAMSD_anomalous((parameter.TAMSD.MinWindowSize:parameter.TAMSD.MaxWindowSize)', list_TAMSD(parameter.TAMSD.MinWindowSize:parameter.TAMSD.MaxWindowSize,1)  );
%                                     elseif ismember(state_interact_num,[6,7])
%                                     [fit_param_total] = fitting_TAMSD_OUP((parameter.TAMSD.MinWindowSize:parameter.TAMSD.MaxWindowSize)', list_TAMSD(parameter.TAMSD.MinWindowSize:parameter.TAMSD.MaxWindowSize,1)  ,list_min_max(n,2)-list_min_max(n,1)+1);
%                                    fit_param(n,:)=fit_param_total([1,2,end]);
%                                     end
                                    
                                end
                                fit_param(:,1)=fit_param(:,1)*parameter.pixel_size_um^2/parameter.Frameduration;
                                list_MSD_param{cp_interact,1}=fit_param(:,1:2);
                            end
                        end
                        
                        
                        max_n=0;
                        for n=1: cp_interact
                            if size(list_MSD_param{n,1},1)>max_n
                                max_n= size(list_MSD_param{n,1},1);
                            end
                        end
                        data_sheet=nan(max_n,8);
                        for n=1: cp_interact
                            data_sheet(1:size(list_MSD_param{n,1},1),2*(n-1)+1:2*n)=list_MSD_param{n,1};
                        end
                        csvwrite([save_path,filesep,group,' ',movie_name{n_mov},' ',list_name_molecule{ch},' D alpha for each coloc state.csv'],data_sheet);
                    else
                        disp([movie_name{1,n_mov},'-',channel{1,ch},'_ state'])
                        
                    end
                end
                
                
                
                
                %%
                
                
                
                
            end
            %                 image_markov=getframe(gcf);
            %                 imwrite(image_markov.cdata,['percentage_state_bef_aft_stim_distrib_start_',receptor{1,n_rec},'-',arrestin{1,n_arr},'-',channel{1,ch},'.jpg'],'jpg')
            %
        end
    end
end
