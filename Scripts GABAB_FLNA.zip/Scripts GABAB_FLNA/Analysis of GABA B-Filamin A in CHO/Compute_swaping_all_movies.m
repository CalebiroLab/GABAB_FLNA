% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)

% script for creating new OBJ from interaction files
clear;
close all;
global_folders;
movie_list;
parameter_list;

list_error_swap_all={};
movie_fields=fieldnames(movie_list);
for n_group=1:numel(movie_fields)
    disp( movie_fields{n_group})
movie_name_list =movie_list.(movie_fields{n_group});
[list_error_swap]=swap_after_interaction_movie_list_v1(movie_name_list,global_folders);
if ~isempty(list_error_swap)
list_error_swap_all(size(list_error_swap,1)+1:size(list_error_swap,1)+size(list_error_swap,1),:)=list_error_swap;
end
end
