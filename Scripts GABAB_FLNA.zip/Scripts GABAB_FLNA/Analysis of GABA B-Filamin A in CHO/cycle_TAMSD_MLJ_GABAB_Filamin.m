% Copyright (c) Lanoisel�e and Calebiro 2023
% Please cite:
% Filamin A organizes gamma-aminobutyric acid type B receptors at the plasma membrane
% ML Jobin et al.
% Nature Communications 14 (1), 1-14 (2023)
clear;
close all;
global_folders;
movie_list;
parameter_list;

group_names = fieldnames(movie_list);

movie_name_list={};
for n_group=1:numel(group_names)
    movie_name_list= [movie_name_list,movie_list.(group_names{n_group})];
end
moviename=movie_name_list;
list_error={};
n_error=0;
for channel_number=2%1:2
   
    for n_mov=1:numel(moviename)
       % try
            disp(['computing ',moviename{n_mov},'-C',num2str(channel_number)])
            min_traj_duration=120;
            max_window=10;
            starMSD_v9_msk_YL_v2(moviename{n_mov}, channel_number,400,min_traj_duration,max_window, parameter, global_folders);
            close all
%         catch e
%             n_error=n_error+1;
%             list_error{n_error,1}=e;
%             disp(['Error: ',e.message])
%         end
    
    end
end
